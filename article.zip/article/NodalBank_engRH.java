package com.tcs.nregs.FundFR.reqhand;
import com.tcs.nregs.FundFR.dao.NodalBankDAO;
import com.tcs.nregs.FundFR.dao.NodalBankDAOImpl;
import com.tcs.nregs.FundFR.dao.FundFR_engDAO;
import com.tcs.nregs.FundFR.dao.FundFR_engDAOImpl;
import com.tcs.nregs.NewReports.dao.NewReportsdao;
import com.tcs.nregs.NewReports.dao.NewReportsdaoImpl;
import com.tcs.nregs.common.dao.Common_engDAO;
import com.tcs.nregs.common.dao.Common_engDAOImpl;
import com.tcs.sgv.common.requesthandler.BaseHandler;
import com.tcs.sgv.common.util.FileUtility;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;

import java.sql.Timestamp;

import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.StringTokenizer;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import java.util.GregorianCalendar;
import jxl.Workbook;
import jxl.WorkbookSettings;
import jxl.format.Border;
import jxl.format.BorderLineStyle;
import jxl.format.Alignment;
import jxl.format.VerticalAlignment;
import jxl.format.Colour;
import jxl.format.UnderlineStyle;

import jxl.write.Label;
import jxl.write.Number;
import jxl.write.NumberFormats;
import jxl.write.WritableCell;
import jxl.write.WritableCellFormat;
import jxl.write.WritableFont;
import jxl.write.WritableSheet;
import jxl.write.WritableWorkbook;
import jxl.write.WriteException;

import java.text.*;
import org.apache.log4j.Logger;
public class NodalBank_engRH extends BaseHandler
{
  String lStrreturnPage=null;
  String lStrAction=null;
  String lStrdistrict=null;
  String lStrmandal=null;
  String lStrmyear=null;

  String lStrmonth="";
  String type="-1";String Finyear="";String lStryear="-1";String FinYear="-1";String lStrstate="01";String lang="-1";String lStrpanchayat="-1";
  ArrayList totList=new ArrayList();
  ArrayList dlist=new ArrayList();
  Common_engDAO comDao = new Common_engDAOImpl();
  NodalBankDAO ndao=new NodalBankDAOImpl();
  FundFR_engDAO cdao=new FundFR_engDAOImpl();
	NewReportsdao Ndao=new NewReportsdaoImpl();

  static Logger glogger = Logger.getLogger( NodalBank_engRH.class);

    public String processRequest(HttpServletRequest request, HttpServletResponse response)throws Exception
    {
HttpSession session=request.getSession();

      if(request.getParameter("actionVal")!=null)
      {
        lStrAction=request.getParameter("actionVal");
      }
      if(session.getAttribute("StateKey")!=null && session.getAttribute("StateKey")!="" )
		{
  	  lStrstate=(String)session.getAttribute("StateKey");
  	  request.setAttribute("StateKey", lStrstate);
		}
      if(request.getParameter("lang")!=null)
      {
          lang=request.getParameter("lang");
      }
      if(request.getParameter("type")!=null)
      {
          lang=request.getParameter("type");
      }
      if(session.getAttribute("StateKey")!=null && !session.getAttribute("StateKey").equals("-1"))
      {
    	  lStryear=(String)session.getAttribute("StateKey");
			request.setAttribute("StateKey",lStryear);
      }
      if(session.getAttribute("year_val")!=null)
      {
      lStryear=(String)session.getAttribute("year_val");
      lStrmonth=(String)session.getAttribute("month_val");
      }
      else
      {
         	Calendar calendar = new GregorianCalendar();
           	lStrmonth=Integer.toString(calendar.get(Calendar.MONTH)+1);
           	
           	 if(calendar.get(Calendar.MONTH)<3)
                {
           		 lStryear=Integer.toString(calendar.get(Calendar.YEAR)-1);
                 }
                else
                {
               	 lStryear=Integer.toString(calendar.get(Calendar.YEAR));
                }
           	 if(lStrmonth.length()<2)
           	 {
           		 lStrmonth="0"+lStrmonth; 
           	 }
           	
      }
     /* int year_int= Integer.parseInt(lStryear) ;  
	  Finyear=(year_int)+"-"+(year_int+1);

	if(Integer.parseInt(lStrmonth)<=3)
	{
		lStryear=(year_int+1)+"";
		
    }*/
	FinYear=Ndao.getFinYear(lStryear);
      
       if(lStrAction !=null && lStrAction.equalsIgnoreCase("AllMand"))
      {
      try
      {

          if(Integer.parseInt(lStrmonth)<=3&&Integer.parseInt(lStrmonth)!=0)
        {
         lStryear=(Integer.parseInt(lStryear)+1)+"";
        }
        if(Integer.parseInt(lStrmonth)==0)
        {
          lStrmonth="12";
          lStryear=(Integer.parseInt(lStryear)-1)+"";
        }
         lStrmyear=lStryear+lStrmonth;
      String lStrdistrict="-1";
      ArrayList ResultList =new ArrayList();
     // ArrayList dlist=cdao.getDnameFyearDtls(lStrdistrict,lStrmyear);
      ArrayList dlist=cdao.getDnameFyearNewDtls(lStrstate,lStrdistrict,lStrmyear);
    ResultList=ndao.getAllMandDtls(lStrstate,lStrmyear,FinYear,type,lang);
     
        byte lbdata[]=null;
        lbdata = FileUtility.getBytesFromFile(new File(this.excelWorks(ResultList,1,6,3,"NodalBankAllmand.xls",dlist)));
        File f = new File(this.excelWorks(ResultList,1,6,3,"NodalBankAllmand.xls",dlist));
    	if(f.exists()){
    		f.delete();
    	}
        request.setAttribute("File",lbdata);
        request.setAttribute("report","Nodal Bank report");
        request.setAttribute("ContentType","application/vnd.ms-excel");
        response.addHeader("Content-Disposition", "attachment;filename=Nodal Bank report.xls");
        request.setAttribute("type",type);
        lStrreturnPage="ExcelExportReturnPage_eng";
       
        
         }
      catch(Exception e)
      {
        System.out.println(e);
      }
      }
      if(lStrAction !=null && lStrAction.equalsIgnoreCase("MandBranch"))
      {
      try
      {
      
          if(Integer.parseInt(lStrmonth)<=3&&Integer.parseInt(lStrmonth)!=0)
        {
         lStryear=(Integer.parseInt(lStryear)+1)+"";
        }
        if(Integer.parseInt(lStrmonth)==0)
        {
          lStrmonth="12";
          lStryear=(Integer.parseInt(lStryear)-1)+"";
        }
         lStrmyear=lStryear+lStrmonth;

       
      
      ArrayList ResultList =new ArrayList();
      String lStrdistrict="-1";
   //   ArrayList dlist=cdao.getDnameFyearDtls(lStrdistrict,lStrmyear);
      ArrayList dlist=cdao.getDnameFyearNewDtls(lStrstate,lStrdistrict,lStrmyear);
     ResultList=ndao.getAllMandBranchDtls(lStrstate,lStrmyear,FinYear,type,lang);
        byte lbdata[]=null;
        lbdata = FileUtility.getBytesFromFile(new File(this.excelWorks(ResultList,1,6,3,"NodalBankMandBranch.xls",dlist)));
        File f = new File(this.excelWorks(ResultList,1,6,3,"NodalBankMandBranch.xls",dlist));
    	if(f.exists()){
    		f.delete();
    	}
        request.setAttribute("File",lbdata);
        request.setAttribute("report","Nodal Bank Mandal & Branch wise report");
        request.setAttribute("ContentType","application/vnd.ms-excel");
        response.addHeader("Content-Disposition", "attachment;filename=Nodal Bank Mandal & Branch wise report.xls");
        request.setAttribute("type",type);
        lStrreturnPage="ExcelExportReturnPage_eng";
       
        
         }
      catch(Exception e)
      {
        System.out.println(e);
      }
      }
       if(lStrAction !=null && lStrAction.equalsIgnoreCase("BranchWise"))
      {
      try
      {
      
          if(Integer.parseInt(lStrmonth)<=3&&Integer.parseInt(lStrmonth)!=0)
        {
         lStryear=(Integer.parseInt(lStryear)+1)+"";
        }
        if(Integer.parseInt(lStrmonth)==0)
        {
          lStrmonth="12";
          lStryear=(Integer.parseInt(lStryear)-1)+"";
        }
         lStrmyear=lStryear+lStrmonth;

      String lStrdistrict="-1";
      ArrayList ResultList =new ArrayList();
    //  ArrayList dlist=cdao.getDnameFyearDtls(lStrdistrict,lStrmyear);
      ArrayList dlist=cdao.getDnameFyearNewDtls(lStrstate,lStrdistrict,lStrmyear);
      dlist=comDao.getAllCommonDtls(lStrstate,lStrdistrict, lStrmandal, lStrpanchayat,lStryear ,lStrmonth);
     ResultList=ndao.getAllBranchDtls(lStrstate,lStrmyear,FinYear,type,lang);
        byte lbdata[]=null;
        lbdata = FileUtility.getBytesFromFile(new File(this.excelWorks(ResultList,1,6,1,"NodalBankBranchDtls.xls",dlist)));
        File f = new File(this.excelWorks(ResultList,1,6,1,"NodalBankBranchDtls.xls",dlist));
    	if(f.exists()){
    		f.delete();
    	}
        request.setAttribute("File",lbdata);
        request.setAttribute("report","Nodal Bank Branch wise report");
        request.setAttribute("ContentType","application/vnd.ms-excel");
        response.addHeader("Content-Disposition", "attachment;filename=Nodal Bank Branch wise report.xls");
        request.setAttribute("type",type);
        request.setAttribute("type",type);
        lStrreturnPage="ExcelExportReturnPage_eng";
       
        
         }
      catch(Exception e)
      {
        System.out.println(e);
      }
      }
       if(lStrAction !=null && lStrAction.equalsIgnoreCase("BankWise"))
      {
      try
      {
      
          if(Integer.parseInt(lStrmonth)<=3&&Integer.parseInt(lStrmonth)!=0)
        {
         lStryear=(Integer.parseInt(lStryear)+1)+"";
        }
        if(Integer.parseInt(lStrmonth)==0)
        {
          lStrmonth="12";
          lStryear=(Integer.parseInt(lStryear)-1)+"";
        }
     //    lStrmyear=lStryear+lStrmonth;

      String lStrmyear=lStryear+lStrmonth;
      ArrayList ResultList =new ArrayList();
      String lStrdistrict="-1";
      ArrayList dlist=cdao.getDnameFyearNewDtls(lStrstate,lStrdistrict,lStrmyear);
      ResultList=ndao.getAllBankDtls(lStrstate,lStrmyear,FinYear,type,lang);
     
      
        byte lbdata[]=null;
        lbdata = FileUtility.getBytesFromFile(new File(this.excelWorks(ResultList,1,6,1,"NodalBankWiseDtls.xls",dlist)));
        File f = new File(this.excelWorks(ResultList,1,6,1,"NodalBankWiseDtls.xls",dlist));
    	if(f.exists()){
    		f.delete();
    	}
        request.setAttribute("File",lbdata);
        request.setAttribute("report","Nodal Bank wise report");
        request.setAttribute("ContentType","application/vnd.ms-excel");
        response.addHeader("Content-Disposition", "attachment;filename=Nodal Bank wise report.xls");
        request.setAttribute("type",type);
      
        lStrreturnPage="ExcelExportReturnPage_eng";
       
        
         }
      catch(Exception e)
      {
        System.out.println(e);
      }
      }
       
       if(lStrAction !=null && lStrAction.equalsIgnoreCase("Exception"))
       {
       try
       {
       
           if(Integer.parseInt(lStrmonth)<=3&&Integer.parseInt(lStrmonth)!=0)
         {
          lStryear=(Integer.parseInt(lStryear)+1)+"";
         }
         if(Integer.parseInt(lStrmonth)==0)
         {
           lStrmonth="12";
           lStryear=(Integer.parseInt(lStryear)-1)+"";
         }
          lStrmyear=lStryear+lStrmonth;

       
       ArrayList ResultList =new ArrayList();
       ArrayList dlist=cdao.getDnameFyearDtls(lStrstate,lStrdistrict,lStrmyear);
       
      ResultList=ndao.getFTRExceptionDtls(lStrdistrict, lStrmandal);
         byte lbdata[]=null;
         lbdata = FileUtility.getBytesFromFile(new File(this.excelWorks(ResultList,1,6,1,"NodalBankWiseDtls.xls",dlist)));
         File f = new File(this.excelWorks(ResultList,1,6,1,"NodalBankWiseDtls.xls",dlist));
     	if(f.exists()){
     		f.delete();
     	}
         request.setAttribute("File",lbdata);
         request.setAttribute("report","Nodal Bank Exception report");
         request.setAttribute("ContentType","application/vnd.ms-excel");
         response.addHeader("Content-Disposition", "attachment;filename=Nodal Bank wise report.xls");
         lStrreturnPage="ExcelExportReturnPage_eng";
        
         
          }
       catch(Exception e)
       {
         System.out.println(e);
       }
       }

     
      

        return lStrreturnPage;
   }

public String  excelWorks(ArrayList ResultList,int beginCol,int beginRow,int numberFormatCol,String fName,ArrayList topdtls) throws WriteException
{
WritableWorkbook wwb=null;
FileInputStream finStream=null;
WritableSheet wsheet=null;
WritableCell wc=null;
FileOutputStream fos=null;
String lStrFilePath="";
Workbook wb=null;
String lStrLoginName=new String("ExcelToExport");

String heading= " During the year  "+topdtls.get(0)+"  (Cummulative)";
         try
         {
            Date dt = new Date();
            Timestamp ts = new Timestamp(dt.getTime());
            String lStrTemp = "" + ts;
            StringTokenizer lStrTok = new StringTokenizer(lStrTemp , " " );
            lStrTemp = lStrTok.nextToken();
            StringBuffer sb = new StringBuffer("NodalBankReport"); 
            sb.append("("); 
            sb.append(lStrTemp); 
            sb.append(").xls"); 
            lStrFilePath = sb.toString();
            File file = new File(lStrLoginName + "/" ,lStrFilePath);
            File lDir = new File(lStrLoginName);
            //System.out.println("The File Path is Excel Export "+lStrFilePath);
            if(!lDir.isDirectory())
            {
                lDir.mkdir();
            }
            if(file.exists())
            {
             file.delete();
            }
            //System.out.println("The LFILE is Excel Export "+file);
            String XLfileNameStr = "C:/Templates/"+fName;
            WorkbookSettings wbs=new WorkbookSettings();
            File lfile = new File(XLfileNameStr);
            finStream = new FileInputStream(XLfileNameStr); 
            fos=new FileOutputStream(file);
            wb=Workbook.getWorkbook(lfile);   // Getting workbook from the given Template file
            wwb=Workbook.createWorkbook(fos,wb); // Preparing a copy of the work book to display
            wsheet=wwb.getSheet("Data");
            //WritableCellFormat FloatCellFmt = new WritableCellFormat(NumberFormats.FLOAT);
            //WritableCellFormat lFloatFmt = new WritableCellFormat(NumberFormats.FLOAT);
            WritableCellFormat DataCellFmt;

         DataCellFmt=new WritableCellFormat();
                DataCellFmt.setBorder(Border.ALL,BorderLineStyle.THIN);
          Label  lLblName = new Label(2,2,heading, DataCellFmt);
                  wsheet.addCell(lLblName);
 
 
 
        
  for(int i=0;i<ResultList.size();i++)
 {
     
     ArrayList record=(ArrayList)ResultList.get(i);
     wsheet.insertRow(beginRow);
     DataCellFmt=new WritableCellFormat(NumberFormats.INTEGER);
     DataCellFmt.setBorder(Border.ALL,BorderLineStyle.THIN);
     int SrData=i+1;
     Number intDataCell=new Number(0,beginRow,SrData,DataCellFmt);

     wsheet.addCell(intDataCell);
     for(int j=0;j<record.size();j++)
      {
//System.out.println(j);
           if(j>=numberFormatCol)
          {
             DataCellFmt=new WritableCellFormat(NumberFormats.FLOAT);
            // DataCellFmt=new WritableCellFormat(NumberFormats.INTEGER);
             DataCellFmt.setBorder(Border.ALL,BorderLineStyle.THIN);
                float cellData=Float.parseFloat((String)record.get(j));
                Number fltDataCell=new Number(beginCol,beginRow,cellData,DataCellFmt);
                wsheet.addCell(fltDataCell);
          }
         else{
                DataCellFmt=new WritableCellFormat();
                DataCellFmt.setBorder(Border.ALL,BorderLineStyle.THIN);
                String cellData=(String)record.get(j);
                Label ReportLevelCell=new Label(beginCol,beginRow,cellData,DataCellFmt);
                wsheet.addCell(ReportLevelCell);
            }
         
          beginCol=beginCol+1;
      }
      beginRow=beginRow+1;
      beginCol=1;
 }

 
  wwb.write();
                 
             
         }
         catch(Exception e)
         {
           System.out.println(e);
         }finally{
        	 
        	 try {
				if(wwb!=null)
					wwb.close();
				if(finStream!=null)
					finStream.close();
				
			} catch (IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
         }
        return lStrLoginName + "/" +lStrFilePath;
}
   
}//end of class

