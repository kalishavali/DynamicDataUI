package com.tcs.nregs.FundFR.dao;



import java.io.IOException;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;

import oracle.jdbc.OraclePreparedStatement;

import org.apache.log4j.Logger;

import com.tcs.nregs.fileupload.dao.LoginDAO;
import com.tcs.nregs.util.DataAccess;
import com.tcs.sgv.common.util.DBConnection;
public class NodalBankLogin_engDAOImpl implements NodalBankLogin_engDAO {

	private Logger oslogger = Logger.getLogger(NodalBankLogin_engDAOImpl.class);
	String lStrQuery=null;
	
	public String validateLogin(String uname, String passw) throws Exception {
     
        ArrayList<ArrayList<String>> dataLst = new ArrayList();
        String check="false";
        try
        {
            StringBuffer lSb = new StringBuffer();
            lSb.append("select t.ROLE_ID,t.user_id from nodal_login_master t where t.state_code='01' and upper(t.user_id)=upper('"+uname+"') and t.passwd='"+passw+"'");

            lStrQuery=lSb.toString();
            dataLst=DataAccess.setData(lStrQuery);
            
            if(dataLst.size()>0) {
               check=(String)((ArrayList)dataLst.get(0)).get(0);
            }
           
        }   //end of try 
        catch(Exception lexp)
        {
            oslogger.error("Exception in NodalBankLogin_engDAOImpl in method validateLogin "+lexp);
            throw lexp;
        }

      return check; 
	}
	public String validateGoLogin(String uname, String passw) throws Exception {
	     
        ArrayList<ArrayList<String>> dataLst = new ArrayList();
        String check="false";
        try
        {
            StringBuffer lSb = new StringBuffer();
            lSb.append("select t.user_name from GO_LOGIN_MASTER t where t.state_code='01' and upper(t.user_id)=upper('"+uname+"') and t.passwd='"+passw+"'");

            lStrQuery=lSb.toString();
            dataLst=DataAccess.setData(lStrQuery);
            
            if(dataLst.size()>0) {
               check="success";
            }
           
        }   //end of try 
        catch(Exception lexp)
        {
            oslogger.error("Exception in NodalBankLogin_engDAOImpl in method validateGoLogin "+lexp);
            throw lexp;
        }

      return check; 
	}
	public String validateLogin1(String uname, String passw) throws Exception {
	     
        ArrayList<ArrayList<String>> dataLst = new ArrayList();
        String check="false";
        try
        {
            StringBuffer lSb = new StringBuffer();
            lSb.append("select * from gos_login_master");

            lStrQuery=lSb.toString();
            dataLst=DataAccess.setData(lStrQuery);
            
          /*  if(dataLst.size()>0) {
               check=(String)((ArrayList)dataLst.get(0)).get(0);
            }*/
           
        }   //end of try 
        catch(Exception lexp)
        {
            oslogger.error("Exception in NodalBankLogin_engDAOImpl in method validateLogin "+lexp);
            throw lexp;
        }

      return check; 
	}
	public boolean ChangePassword(String uname, String passw, String newpassw) throws Exception {
	     
        int res=0;
        boolean check=false;
        try
        {
            StringBuffer lSb = new StringBuffer();
            lSb.append("update nodal_login_master t set t.passwd='"+newpassw+"' , t.reset_date=sysdate where upper(t.user_id)=upper('"+uname+"') and t.passwd='"+passw+"'");

            lStrQuery=lSb.toString();
            
            res=DataAccess.executeUpdateQuery2("NodalBankLogin_engDAOImpl","ChangePassword",lStrQuery);
            
            if(res>0) {
               check=true;
            }
            else
            {
               check=false;
            }
        }   //end of try 
        catch(Exception lexp)
        {
            oslogger.error("Exception in PdLoginDAOImpl in method validateLogin "+lexp);
            throw lexp;
        }

      return check; 
	}
	//go Change Password
	public boolean GoChangePassword(String uname, String passw, String newpassw) throws Exception {
	     
        int res=0;
        boolean check=false;
        try
        {
            StringBuffer lSb = new StringBuffer();
            lSb.append("update go_login_master t set t.passwd='"+newpassw+"' , where upper(t.user_id)=upper('"+uname+"') and t.passwd='"+passw+"'");

            lStrQuery=lSb.toString();
            
            res=DataAccess.executeUpdateQuery2("NodalBankLogin_engDAOImpl","GoChangePassword",lStrQuery);
            
            if(res>0) {
               check=true;
            }
            else
            {
               check=false;
            }
        }   //end of try 
        catch(Exception lexp)
        {
            oslogger.error("Exception in NodalBankLogin_engDAOImpl in method GoChangePassword "+lexp);
            throw lexp;
        }

      return check; 
	}
	public ArrayList getExcessLimitFTRsHdngs(String roleId)  throws Exception
	{
		ArrayList subList=new ArrayList();
		ArrayList headerList=new ArrayList();
		subList.add("S.No.");		
		subList.add("District");
        subList.add("Mandal");
        subList.add("FTO No");
        subList.add("FTO Date ");
       if( roleId.equals("02"))//for chenchu
        {
    	   subList.add("Account No");
           subList.add("In Favour Of");
        }
       else
       {
    	   subList.add("Account No.");
    	   subList.add("Beneficiary Name");
    	   subList.add("Head");
           subList.add("Purpose");
       }
       
        subList.add("Amount");
       
        subList.add("Select");
        headerList.add(subList);
        return headerList;
	}
	
	public ArrayList getPurposeList(String state, String type) throws Exception
	{
		ArrayList rList=new ArrayList();		 
		try
		{		
			ArrayList inputParamList= new ArrayList();
			inputParamList.add(state);
			inputParamList.add(type);
			
			lStrQuery="call NODAL_BANK.purpose_list(?,?,?)";
			rList=DataAccess.setDatawithStgProcCall("Login","NodalBankLogin_engDAOImpl", "getPurposeList", lStrQuery,inputParamList);
		}
		catch(Exception e)
		{
			e.printStackTrace();
		}
		return 	rList;	
	}
	
	public ArrayList getExcessLimitFTRs(String sid, String purpose) throws Exception
	{
		ArrayList rList=new ArrayList();
		try
		{
			ArrayList inputParamList= new ArrayList();
			inputParamList.add(sid);
			inputParamList.add(purpose);
			inputParamList.add("CRD");
			
			lStrQuery="call NODAL_BANK_AP.MCC_FTO_PENDING_APPROVAL_AP(?,?,?,?)";
			rList=DataAccess.setDatawithStgProcCall("Login","NodalBankLogin_engDAOImpl", "getExcessLimitFTRs", lStrQuery,inputParamList);	
		}
		catch(Exception e)
		{
			e.printStackTrace();
		}
		return 	rList;	
	}
	public ArrayList getVRFHdngs()  throws Exception
	{
		ArrayList subList=new ArrayList();
		ArrayList headerList=new ArrayList();
		subList.add("S.No.");	
		subList.add("Program");
		subList.add("District");
        subList.add("Mandal");
        subList.add("FTO No");
        subList.add("FTO Date ");
        subList.add("Account No");
        subList.add("In Favour Of");
        subList.add("Amount");
        
        subList.add("Select");
        headerList.add(subList);
        return headerList;
	}
	
	public ArrayList getVRFDtls(String state) throws Exception // yet to be modified
	{
		ArrayList rList=new ArrayList();
		 
		try
		{
			ArrayList inputParamList= new ArrayList();
			inputParamList.add(state);
			
			lStrQuery="call NODAL_BANK.SENT_FOR_VERIFICATION_EGS(?,?)";
			rList=DataAccess.setDatawithStgProcCall("Login","NodalBankLogin_engDAOImpl", "getVRFDtls", lStrQuery,inputParamList);
		}
		catch(Exception e)
		{
			e.printStackTrace();
		}
		return 	rList;	
	}
	
	public ArrayList getChenchuExcessLimitFTRs(String State) throws Exception
	{
		ArrayList rList=new ArrayList();
		 
		try
		{
			ArrayList inputParamList= new ArrayList();
			inputParamList.add(State);
			
			lStrQuery="call NODAL_BANK.CCC_FTO_PENDING_APPROVAL(?,?)";
			rList=DataAccess.setDatawithStgProcCall("Login","NodalBankLogin_engDAOImpl", "getChenchuExcessLimitFTRs", lStrQuery,inputParamList);		

		}
		catch(Exception e)
		{
			e.printStackTrace();
		}
		return 	rList;	
	}
	public ArrayList getDCCExcessLimitFTRs(String state,String purpose) throws Exception
	{
		ArrayList rList=new ArrayList();
		try
		{
			ArrayList<String> inputParamList= new ArrayList<String>();
			inputParamList.add(state);
			inputParamList.add(purpose);
			inputParamList.add("CRD");
			inputParamList.add("-1");
			inputParamList.add("-1");
			lStrQuery="call NODAL_BANK_AP.DCC_FTO_PENDING_APPROVAL_AP(?,?,?,?,?,?)";
			rList=DataAccess.setDatawithStgProcCall("Login","NodalBankLogin_engDAOImpl", "getDCCExcessLimitFTRs", lStrQuery,inputParamList);	
		}
		catch(Exception e)
		{
			e.printStackTrace();
		}
		return 	rList;	
	}
	
	public ArrayList getDAPExcessLimitFTRs(String state,String purpose) throws Exception
	{
		ArrayList rList=new ArrayList();
		 String condtn="";
		try
		{
			ArrayList inputParamList= new ArrayList();
			inputParamList.add(state);
			inputParamList.add(purpose);
			inputParamList.add("CRD");
			lStrQuery="call NODAL_BANK_AP.DAP_FTO_PENDING_APPROVAL_AP(?,?,?,?)";
			rList=DataAccess.setDatawithStgProcCall("Login","NodalBankLogin_engDAOImpl", "getDAPExcessLimitFTRs", lStrQuery,inputParamList);	
		}
		catch(Exception e)
		{
			e.printStackTrace();
		}
		return 	rList;	
	}
	
	public ArrayList getFTRDtls(String FTRNo,String ptype) throws Exception
	{
		ArrayList rList=new ArrayList();
		
		if(ptype.equals("")||ptype.equals(null))
				ptype="-1";
		
		try
		{

			ArrayList inputParamList= new ArrayList();
			inputParamList.add(ptype);
			inputParamList.add(FTRNo.substring(0, 1));
			inputParamList.add(FTRNo);
			
			lStrQuery="call NODAL_BANK.FTR_DETAILS_EGS(?,?,?,?)";
			rList=DataAccess.setDatawithStgProcCall("Login","NodalBankLogin_engDAOImpl", "getChenchuFTRDtls", lStrQuery,inputParamList);
		/*String program="";
		String query1="";
		String query2="";
		String query3="";
		String did="";
		program=FTRNo.substring(0,1);
		did=FTRNo.substring(1,3);
		if(ptype.equalsIgnoreCase("m"))
		{
			 query3=" AND M.TRANSACTION_ID=T.TRANSACTION_ID AND M.PCC_INFO_CODE=T.PCC_INFO_CODE\n" +
				"AND M.WORK_CODE=WR.WORK_CODE AND M.PCC_INFO_CODE=WR.PCC_INFO_CODE";

		if(program.equalsIgnoreCase("9"))
		{
			query1=",WR.WORK_CODE,WR.WORK_NAME";
			query2=",ACCT_MATERIALS M,WORK_REGISTRATION_"+did+" WR";

		}
		else if(program.equalsIgnoreCase("8"))
		{
			query1=",WR.WORK_CODE,WR.WORK_NAME";
			query2=",DCC.DC_ACCT_MATERIALS M,DCC.DC_WORK_REGISTRATION_"+did+"  WR";

		}
		
		}
		
		
		if(program.equalsIgnoreCase("9"))//MCC
		{
			lStrQuery="SELECT T.TRANSACTION_ID,T.TRANSACTION_TYPE,T.VOUCHER_NO,\n" +
			"       T.DEBIT,TO_CHAR(T.TRANSACTION_DATE,'DD-MON-YYYY') TRAN_DATE, NVL(B.ACCOUNT_NO,'-') ACTNO,NVL(B.IN_FAVOUR_OF,'-') NAME,\n" + 
			"       NVL(REPLACE(B.REASON,'Director :',''),'-') REASON "+query1+"\n" + 
			"FROM ACCT_TRANSACTIONS T, BANK_FTR_DETAILS_TAB B "+query2+"\n" + 
			"WHERE T.VOUCHER_NO IS NOT NULL AND T.FTR_NO=B.FTR_NO\n" +
			"AND T.FTR_NO='"+FTRNo+"' "+query3+" ";
			//"AND T.FTR_NO='9130109000005'";
			
		}
		else if(program.equalsIgnoreCase("8"))//DCC
		{
			lStrQuery=
				"SELECT  T.TRANSACTION_ID,T.TRANSACTION_TYPE,T.VOUCHER_NO, T.DEBIT,\n" +
				"        TO_CHAR(T.TRANSACTION_DATE,'DD-MON-YYYY') TRAN_DATE, NVL(B.ACCOUNT_NO,'-') ACTNO,NVL(B.IN_FAVOUR_OF,'-') NAME,\n" + 
				"        CASE WHEN B.STATUS='R' THEN NVL(REPLACE(B.REASON,'Director :',''),'-') ELSE '-' END REASON "+query1+"\n" + 
				"FROM  DCC.DC_ACCT_TRANSACTIONS T, BANK_FTR_DETAILS_TAB B "+query2+"\n" + 
				"WHERE T.VOUCHER_NO IS NOT NULL AND T.FTR_NO=B.FTR_NO \n" +
				"AND T.FTR_NO='"+FTRNo+"' "+query3+"";
			//	"AND T.FTR_NO='8140410000227'";

		}
		else if(program.equalsIgnoreCase("1"))//DAP
		{

			lStrQuery="SELECT T.TRANSACTION_ID,T.TRANSACTION_TYPE,T.VOUCHER_NO, T.DEBIT,\n" +
			"        TO_CHAR(T.TRANSACTION_DATE,'DD-MON-YYYY') TRAN_DATE, NVL(B.ACCOUNT_NO,'-') ACTNO,NVL(B.IN_FAVOUR_OF,'-') NAME,\n" + 
			"        CASE WHEN B.STATUS='R' THEN NVL(REPLACE(B.REASON,'Director :',''),'-') ELSE '-' END REASON\n" + 
			"FROM  ACCTD_TRANSACTIONS T, BANK_FTR_DETAILS_TAB B\n" + 
			"WHERE T.VOUCHER_NO IS NOT NULL AND T.FTR_NO=B.FTR_NO \n" +
			"AND T.FTR_NO='"+FTRNo+"'";
			//"AND T.FTR_NO='1120010000001'";
		}
			
	



			
		rList=DataAccess.setData("NodalBankLogin_engDAOImpl","getFTRDtls",lStrQuery);*/
		}
		catch(Exception e)
		{
			e.printStackTrace();
		}
		return 	rList;	
	}
	
	public ArrayList getChenchuFTRDtls(String FTRNo) throws Exception
	{
		ArrayList rList=new ArrayList();
		
		try
		{

			ArrayList inputParamList= new ArrayList();
			inputParamList.add(FTRNo);
			
			lStrQuery="call NODAL_BANK.FTR_DETAILS_CHENCHU(?,?)";
			rList=DataAccess.setDatawithStgProcCall("Login","NodalBankLogin_engDAOImpl", "getChenchuFTRDtls", lStrQuery,inputParamList);
		/*lStrQuery="SELECT T.TRANSACTION_ID,T.TRANSACTION_TYPE,T.VOUCHER_NO,\n" +
				"       T.DEBIT,TO_CHAR(T.TRANSACTION_DATE,'DD-MON-YYYY') TRAN_DATE,\n" + 
				"       NVL(REPLACE(B.REASON,'CHENCHU PO:',''),'-') REASON\n" + 
				"FROM CHENCHU.CC_ACCT_TRANSACTIONS T, WEB.ACCT_FTR_DETAILS_WBS B\n" + 
				"WHERE T.VOUCHER_NO IS NOT NULL AND T.FTR_NO=B.FTR_NO\n" +				
				"AND T.FTR_NO='"+FTRNo+"'";
		rList=DataAccess.setData("NodalBankLogin_engDAOImpl","getFTRDtls",lStrQuery);*/
		}
		catch(Exception e)
		{
			e.printStackTrace();
		}
		return 	rList;	
	}
	public int ApproveFTRs(ArrayList FTRList) throws Exception
	{
		Connection lcon=DBConnection.getConnection();
		PreparedStatement pstmt=null;
		int val=0;
		try
		{
			lcon.setAutoCommit(false);
			lStrQuery="update bank_ftr_details_tab t set t.status='O',t.approved_date=sysdate\n" +
				"where t.ftr_no=?";
	
			 pstmt=lcon.prepareStatement(lStrQuery);
			
			for(int i=0;i<FTRList.size();i++)
			{
				pstmt.setString(1, FTRList.get(i)+"");
				val=pstmt.executeUpdate();
			}
			lcon.commit();
		}
		catch(Exception e)
		{
			lcon.rollback();
			e.printStackTrace();
		}
		finally
		{
			if(pstmt!=null)
			{
				pstmt.close();
			}
			if(lcon!=null)
			{
				lcon.close();
			}
		}
		
		return val;
	}
	
	public int VerifyFTRs(ArrayList FTRList) throws Exception
	{
		Connection lcon=DBConnection.getConnection();
		PreparedStatement pstmt=null;
		int val=0;
		try
		{
		lStrQuery="UPDATE BANK_FTR_DETAILS_TAB T SET T.STATUS='V' WHERE T.FTR_NO=?";
		pstmt=lcon.prepareStatement(lStrQuery);
		
		for(int i=0;i<FTRList.size();i++)
		{
			pstmt.setString(1, FTRList.get(i)+"");
			val=pstmt.executeUpdate();
		}
		}
		catch(Exception e)
		{
			e.printStackTrace();
		}
		finally
		{
			if(pstmt!=null)
			{
				pstmt.close();
			}
			if(lcon!=null)
			{
				lcon.close();
			}
		}
		
		return val;
	}
	
	public int ApproveChenchuFTRs(ArrayList FTRList) throws Exception
	{
		Connection lcon=DBConnection.getConnection();
		PreparedStatement pstmt=null;
		int val=0;
		try
		{
		lStrQuery="update web.acct_ftr_details_wbs t set t.APPROVAL_DATE=sysdate\n" +
			"where t.ftr_no=?";

		 pstmt=lcon.prepareStatement(lStrQuery);
		
		for(int i=0;i<FTRList.size();i++)
		{
			pstmt.setString(1, FTRList.get(i)+"");
			val=pstmt.executeUpdate();
		}
		}
		catch(Exception e)
		{
			e.printStackTrace();
		}
		finally
		{
			if(pstmt!=null)
			{
				pstmt.close();
			}
			if(lcon!=null)
			{
				lcon.close();
			}
		}
		
		return val;
	}
	
	public int rejectFTRs(String FTRNo,String reason) throws Exception
	{
		Connection lcon=DBConnection.getConnection();
		PreparedStatement pstmt=null;
		int val=0;
		try
		{
		lStrQuery="update bank_ftr_details_tab t set t.status='R',t.REASON=?,t.REJECTED_DATE =sysdate\n" +
			"where t.ftr_no=?";

		 pstmt=lcon.prepareStatement(lStrQuery);
		
		
			pstmt.setString(1, "Director : "+reason);
			pstmt.setString(2, FTRNo);
			val=pstmt.executeUpdate();
		
		}
		catch(Exception e)
		{
			e.printStackTrace();
		}
		finally
		{
			if(pstmt!=null)
			{
				pstmt.close();
			}
			if(lcon!=null)
			{
				lcon.close();
			}
		}
		
		return val;
	}
	
	public int rejectChenchuFTRs(String FTRNo,String reason) throws Exception
	{
		Connection lcon=DBConnection.getConnection();
		PreparedStatement pstmt=null;
		int val=0;
		lcon.setAutoCommit(false);
		try
		{
		lStrQuery="update web.acct_ftr_details_wbs t set t.FLAG='R',t.REASON=?,t.APPROVAL_DATE=sysdate\n" +
			"where t.ftr_no=?";

		 pstmt=lcon.prepareStatement(lStrQuery);
		
		
			pstmt.setString(1, "CHENCHU PO: "+reason);
			pstmt.setString(2, FTRNo);
			val=pstmt.executeUpdate();
			
			lStrQuery=
				"INSERT INTO BANK_REJECTED_FTR_DETAILS_HIST\n" +
				"(ftr_no,amount,account_no,in_favour_of,  benf_bank_name,\n" +
				" ifsc_code,status,reason,rejected_date,pcc_info_code,process_date )\n" + 
				"SELECT ftr_no,\n" + 
				"amount,\n" + 
				"account_no,\n" + 
				"in_favour_of,\n" + 
				"bank_name,\n" + 
				"ifsc_code,\n" + 
				"flag,\n" + 
				"reason,\n" + 
				"approval_date,\n" + 
				"pcc_info_code,\n" + 
				"approval_date \n"+
				" FROM\n" + 
				" web.acct_ftr_details_wbs T WHERE T.FTR_NO =?";

		   pstmt=lcon.prepareStatement(lStrQuery);		   
			pstmt.setString(1, FTRNo);
			pstmt.executeUpdate();
			
			lStrQuery=
				"INSERT INTO WEB.BANK_REJECTED_FTR_DETAILS \n" +
				"(ftr_no,amount,account_no,in_favour_of,benf_bank_name,\n" +
				"ifsc_code,status,reason,rejected_date,pcc_info_code) \n"+
				"SELECT ftr_no,\n" +
				"amount,\n" + 
				"account_no,\n" + 
				"in_favour_of,\n" + 
				"bank_name,\n" + 
				"ifsc_code,\n" + 
				"flag,\n" + 
				"reason,\n" + 
				"approval_date,\n" + 
				"pcc_info_code FROM\n" + 
				" web.acct_ftr_details_wbs T WHERE T.FTR_NO=?"; 

		   pstmt=lcon.prepareStatement(lStrQuery);		   
			pstmt.setString(1, FTRNo);
			pstmt.executeUpdate();
		
		
			lcon.commit();
			
		}
		 catch(Exception lexp)
	     {
			 lcon.rollback();
	          
	          lexp.printStackTrace();
	     }
		finally
		{
			if(pstmt!=null)
			{
				pstmt.close();
			}
			if(lcon!=null)
			{
				lcon.close();
			}
		}
		
		return val;
	}
	public ArrayList getFTRAbstract(String state, String finYear) throws Exception
	{ArrayList rList=new ArrayList();
	
	try
	{
		ArrayList inputParamList= new ArrayList();
		inputParamList.add(state);
		inputParamList.add(finYear);
		
		lStrQuery="call NODAL_BANK.ABSTRACT_FTO_EGS(?,?,?)";
		rList=DataAccess.setDatawithStgProcCall("Login","NodalBankLogin_engDAOImpl", "getFTRAbstract", lStrQuery,inputParamList);
	}
	catch(Exception e)
	{
		e.printStackTrace();
	}
	return 	rList;	
		
	}
	
	public ArrayList getChenchuFTRAbstract(String state) throws Exception
	{ArrayList rList=new ArrayList();
	
	try
	{
		ArrayList inputParamList= new ArrayList();
		inputParamList.add(state);
		
		lStrQuery="call NODAL_BANK.ABSTRACT_FTO_CHENCHU(?,?)";
		rList=DataAccess.setDatawithStgProcCall("Login","NodalBankLogin_engDAOImpl", "getFTRAbstract", lStrQuery,inputParamList);
	/*lStrQuery="select nvl(dm.district_description,'Total') dname,\n" +
		"    count(t.ftr_no) tot,\n" + 
		"    sum(case when t.approval_date is not null and t.flag='N' then 1 else 0 end) apprd,\n" + 
		"    sum(case when t.approval_date is not null and t.flag='R' then 1 else 0 end) apprd,\n" + 
		"    sum(case when t.approval_date is null then 1 else 0 end) pending\n" + 
		"from web.acct_ftr_details_wbs t, district_master dm\n" + 
		"where dm.district_id=substr(t.pcc_info_code,3,2) and substr(t.ftr_no,1,1)='3' \n" + 
		"group by rollup(dm.district_description)";
			rList=DataAccess.setData("NodalBankLogin_engDAOImpl","getFTRAbstract",lStrQuery);*/
	}
	catch(Exception e)
	{
		e.printStackTrace();
	}
	return 	rList;	
		
	}
	@Override
	public ArrayList<ArrayList<String>> getGOUploadData(String year, String userName) throws IOException{
		ArrayList<ArrayList<String>> resultList=new ArrayList<ArrayList<String>>();
		try{	
				if(userName!=null){
					lStrQuery = "select TO_CHAR(TO_DATE(go_date,'DD-MM-YYYY'),'DD-Mon-YYYY'),go_number,subject,file_name,SEQUENCE_NO from UPLOAD_GOS_DATA where TO_CHAR(TO_DATE(go_date,'DD-MM-YYYY'),'YYYY')='"+year+"' AND user_name='"+userName+"' AND IS_DELETE='N' order by TO_DATE(go_date,'DD-MM-YYYY') DESC" ;
		  		}else{
		  			lStrQuery = "select TO_CHAR(TO_DATE(go_date,'DD-MM-YYYY'),'DD-Mon-YYYY'),go_number,subject,file_name,SEQUENCE_NO from UPLOAD_GOS_DATA where TO_CHAR(TO_DATE(go_date,'DD-MM-YYYY'),'YYYY')='"+year+"' AND IS_DELETE='N' order by TO_DATE(go_date,'DD-MM-YYYY') DESC"; 
		  		}
				resultList = DataAccess.setDatawithStgDS("GODATA","NodalBankLogin_engDA", "getGOUploadData",lStrQuery);
		}catch(Exception e) {
			e.printStackTrace();
		}
		/*for(int i=0;i<resultList.size();i++)
		{
			//byte[] bytearray=Base64.decode(resultList.get(i).get(2));
			byte[] bytearray=(new Decoder.BASE64Decoder()).decodeBuffer(resultList.get(i).get(2));
			System.out.println("Decryption");
			System.out.println(bytearray);
			String s=new String(bytearray);
			System.out.println(s);
			resultList.get(i).set(2,s);
		}*/
		return resultList;
	}
	@Override
	public int setGOUploadData(String category, String gonumber, String goDate,
			String subject, String fname, String userName) throws Exception {
		int count=0;
		Connection lcon=null;
		String setGo="";
		OraclePreparedStatement prStr = null;
		int res=0;
		try{
			//lStrQuery="insert into UPLOAD_GOS_DATA (category,go_number,go_date,subject,file_name,user_name,upload_Date,SEQUENCE_NO,IS_DELETE) values ('"+category+"','"+gonumber+"','"+goDate+"','"+subject+"','"+fname+"','"+userName+"',sysdate,UPLOAD_GOS_SEQ.NEXTVAL,'N')";
			Class.forName("oracle.jdbc.driver.OracleDriver");
			lcon = DriverManager.getConnection("jdbc:oracle:thin:@10.100.100.52:1539:NREGS52","apregs_admin","apregs_admin");
			setGo="insert into UPLOAD_GOS_DATA (category,go_number,go_date,subject,file_name,user_name,SEQUENCE_NO,IS_DELETE) values (?,?,?,?,?,?,UPLOAD_GOS_SEQ.NEXTVAL,'N')";
			prStr = (OraclePreparedStatement) lcon.prepareStatement(setGo);
				prStr.setString(1, category);
				prStr.setString(2, gonumber);
				prStr.setString(3, goDate); 
				prStr.setFormOfUse(4, OraclePreparedStatement.FORM_NCHAR);
				prStr.setString(4, new String(subject.getBytes("ISO-8859-1"),"UTF8"));
				prStr.setString(5, fname);
				prStr.setString(6, userName);
			res=prStr.executeUpdate();
			//count = DataAccess.executeUpdateQuery2("NodalBankLogin_engDAOImpl","setGOUploadData", lStrQuery);
		}catch(Exception e) {
			e.printStackTrace();
		}finally{
			if(prStr!=null){
				prStr.close();
			}
			if(lcon!=null){
				lcon.close();
			}
		}
		return res;
	}
	@Override
	public ArrayList<ArrayList<String>> getEditGoData(String sequence_Number,
			String userName) {
		ArrayList<ArrayList<String>> resultList=new ArrayList<ArrayList<String>>();
		try{	
				lStrQuery = "select category,go_number,subject,go_date,file_name from UPLOAD_GOS_DATA where SEQUENCE_NO='"+sequence_Number+"' AND user_name='"+userName+"' order by go_date" ;
		  		resultList = DataAccess.setDatawithStgDS("GODATA","NodalBankLogin_engDAOImpl", "getGOUploadData",lStrQuery);
		}catch(Exception e) {
			e.printStackTrace();
		}
		return resultList;
	}
	@Override
	public int updateGoData(String category, String gonumber, String goDate,
			String subject, String fname, String userName, String sequenceNumber) {
		int count=0;
		try{	
				lStrQuery = "update UPLOAD_GOS_DATA set category='"+category+"',go_number='"+gonumber+"',go_date='"+goDate+"', subject='"+subject+"', file_name='"+fname+"' where user_name='"+userName+"' and SEQUENCE_NO='"+sequenceNumber+"' " ;
				count = DataAccess.executeUpdateQuery2("NodalBankLogin_engDAOImpl","updateGoData",lStrQuery);
		}catch(Exception e) {
			e.printStackTrace();
		}
		return count;
	}
	@Override
	public ArrayList<ArrayList<String>> getMaxFileNumber(String userName, String goNumber) {
		ArrayList<ArrayList<String>> resultList=new ArrayList<ArrayList<String>>();
		try{	
				lStrQuery ="SELECT --SUBSTR(W.FILE_NAME,1,4),SUBSTR(W.FILE_NAME,1,INSTR(W.FILE_NAME,'.',1,REGEXP_COUNT(W.FILE_NAME,'[.]'))-5),\n" +
							"NVL(TO_NUMBER(MAX(SUBSTR(SUBSTR(W.FILE_NAME,1,INSTR(W.FILE_NAME,'.',1,REGEXP_COUNT(W.FILE_NAME,'[.]'))-1),-3))),0) A\n" + 
							"FROM UPLOAD_GOS_DATA  W\n" + 
							"WHERE SUBSTR(W.FILE_NAME,1,4) IN ('"+userName+"')\n" + 
							"AND SUBSTR(W.FILE_NAME,1,INSTR(W.FILE_NAME,'.',1,REGEXP_COUNT(W.FILE_NAME,'[.]'))-5) = '"+userName+"_"+goNumber+"'\n" + 
							"--GROUP BY SUBSTR(W.FILE_NAME,1,4),SUBSTR(W.FILE_NAME,1,INSTR(W.FILE_NAME,'.',1,REGEXP_COUNT(W.FILE_NAME,'[.]'))-5)";
				resultList = DataAccess.setDatawithStgDS("MaxFileNumber","NodalBankLogin_engDAOImpl","getMaxFileNumber",lStrQuery);
		}catch(Exception e) {
			e.printStackTrace();
		}
		return resultList;
	}
	@Override
	public int deleteGoDetails(String sequenceNumber,
			String userName) {
		int count=0;
		try{	
				lStrQuery = "update UPLOAD_GOS_DATA set IS_DELETE='Y' where user_name='"+userName+"' AND SEQUENCE_NO='"+sequenceNumber+"' " ;
				count = DataAccess.executeUpdateQuery2("NodalBankLogin_engDAOImpl","deleteGoDetails",lStrQuery);
		}catch(Exception e) {
			e.printStackTrace();
		}
		return count;
	}
	@Override
	public String validateArticleLogin(String uname, String pass) throws Exception {
		ArrayList<ArrayList<String>> dataLst = new ArrayList();
        String check="false";
        try
        {
            StringBuffer lSb = new StringBuffer();
            lSb.append("select t.user_name from ARTICLE_LOGIN_MASTER t where t.state_code='01' and upper(t.user_id)=upper('"+uname+"') and t.passwd='"+pass+"'");

            lStrQuery=lSb.toString();
            dataLst=DataAccess.setData(lStrQuery);
            
            if(dataLst.size()>0) {
               check="success";
            }
        }catch(Exception lexp){
            oslogger.error("Exception in NodalBankLogin_engDAOImpl in method validateArticleLogin "+lexp);
            throw lexp;
        }
        return check; 
	}
	@Override
	public ArrayList<ArrayList<String>> getArticleUploadData(String seqNumber) throws Exception {
		ArrayList<ArrayList<String>> resultList=new ArrayList<ArrayList<String>>();
		try{	
			if( seqNumber!=null && !seqNumber.equals("") ){
				lStrQuery = "select ARTICLE,FILE_NAME,NEWSPAPER_NAME\n" +
							"from ARTICLES_UPLOAD_DATA\n" + 
							"where SEQUENCE_NO='"+seqNumber+"'";
			}else{
				lStrQuery = "select TO_CHAR(UPLOAD_DATE,'DD-Mon-YYYY'),NEWSPAPER_NAME,DISTRICT_NAME,ARTICLE,FILE_NAME,SEQUENCE_NO\n" +
							"from ARTICLES_UPLOAD_DATA\n" + 
							"order by UPLOAD_DATE DESC";
			}
			resultList = DataAccess.setDatawithStgDS("Article_Upload_Data","NodalBankLogin_engDA", "getArticleUploadData",lStrQuery);
		}catch(Exception e) {
			e.printStackTrace();
		}
		return resultList;
	}
	@Override
	public boolean articleChangePassword(String userName, String password,String newPassword) throws Exception {
	    int res=0;
        boolean check=false;
        try
        {
            StringBuffer lSb = new StringBuffer();
            lSb.append("update ARTICLE_LOGIN_MASTER t set t.passwd='"+newPassword+"' where upper(t.user_id)=upper('"+userName+"') and t.passwd='"+password+"'");
            lStrQuery=lSb.toString();
            res=DataAccess.executeUpdateQuery2("NodalBankLogin_engDAOImpl","articleChangePassword",lStrQuery);
            if(res>0)
               check=true;
            else
               check=false;
        }catch(Exception lexp){
            oslogger.error("Exception in NodalBankLogin_engDAOImpl in method articleChangePassword "+lexp);
            throw lexp;
        }
      return check; 
	}
	@Override
	public ArrayList<ArrayList<String>> getArticleMaxFileNumber(String newspaperName, String districtID) throws Exception {
		ArrayList<ArrayList<String>> resultList=new ArrayList<ArrayList<String>>();
		try{	
				lStrQuery = "SELECT\n" +
							"      NVL(TO_NUMBER(MAx(SUBSTR(SUBSTR(W.FILE_NAME,1,INSTR(W.FILE_NAME,'.',1,REGEXP_COUNT(W.FILE_NAME,'[.]'))-1),-3))),0) A\n" + 
							"FROM ARTICLES_UPLOAD_DATA  W\n" + 
							"WHERE SUBSTR(W.FILE_NAME,1,3) IN (SELECT shortcut_name FROM newspaper_shortcut where newspaper_name='"+newspaperName+"')\n" + 
							"      AND SUBSTR(W.FILE_NAME,1,INSTR(W.FILE_NAME,'.',1,REGEXP_COUNT(W.FILE_NAME,'[.]'))-5) =\n" + 
							"\n" + 
							"      (SELECT shortcut_name FROM newspaper_shortcut where newspaper_name= '"+newspaperName+"_"+districtID+"' ";
				
				resultList = DataAccess.setDatawithStgDS("ArticleMaxFileNumber","NodalBankLogin_engDAOImpl","getArticleMaxFileNumber",lStrQuery);
		}catch(Exception e) {
			e.printStackTrace();
		}
		return resultList;
	}
	@Override
	public ArrayList<ArrayList<String>> getShortcutNewspaper(
			String newspaperName) throws Exception {
		ArrayList<ArrayList<String>> resultList=new ArrayList<ArrayList<String>>();
		try{	
				lStrQuery ="SELECT shortcut_name FROM newspaper_shortcut where newspaper_name='"+newspaperName+"'";
				resultList = DataAccess.setDatawithStgDS("Article_Newspaper_Shortcut","NodalBankLogin_engDAOImpl","getShortcutNewspaper",lStrQuery);
		}catch(Exception e) {
			e.printStackTrace();
		}
		return resultList;
	}
	@Override
	public int setArticleUploadData(String newspaperName, String districtName,
			String articleDiscription, String fname, String userName,String seqNumber)
			throws Exception {
			int res=0;
			Connection lcon=null;
			String setArticle="";
			OraclePreparedStatement prStr = null;
			try{
				Class.forName("oracle.jdbc.driver.OracleDriver");
				lcon = DriverManager.getConnection("jdbc:oracle:thin:@10.138.134.107:1521:webdev","apregs_admin","apregs_admin");
				//lcon = DriverManager.getConnection("jdbc:oracle:thin:@10.100.100.52:1539:NREGS52","apregs_admin","apregs_admin");
				if( seqNumber!=null && !seqNumber.equals("") ){

					setArticle="update Articles_Upload_Data set NEWSPAPER_NAME=?, DISTRICT_NAME=?, ARTICLE=?, FILE_NAME=? " +
								"where USER_NAME=? and SEQUENCE_NO=? ";
					prStr = (OraclePreparedStatement) lcon.prepareStatement(setArticle);
						prStr.setString(1, newspaperName);
						prStr.setString(2, districtName);
						prStr.setFormOfUse(3, OraclePreparedStatement.FORM_NCHAR);
						prStr.setString(3, new String(articleDiscription.getBytes("ISO-8859-1"),"UTF8"));
						prStr.setString(4, fname);
						prStr.setString(5, userName);
						prStr.setString(6, seqNumber);
					res=prStr.executeUpdate();
				}else{
					setArticle="INSERT INTO Articles_Upload_Data(NEWSPAPER_NAME, DISTRICT_NAME, ARTICLE, FILE_NAME, USER_NAME, SEQUENCE_NO)\n" +
								"VALUES(?,?,?,?,?,Articles_Upload_Data_SEQ.NEXTVAL)";
					prStr = (OraclePreparedStatement) lcon.prepareStatement(setArticle);
						prStr.setString(1, newspaperName);
						prStr.setString(2, districtName);
						prStr.setFormOfUse(3, OraclePreparedStatement.FORM_NCHAR);
						prStr.setString(3, new String(articleDiscription.getBytes("ISO-8859-1"),"UTF8"));
						prStr.setString(4, fname);
						prStr.setString(5, userName);
					res=prStr.executeUpdate();
				}
			}catch(Exception e) {
				e.printStackTrace();
			}finally{
				if(prStr!=null){
					prStr.close();
				}
				if(lcon!=null){
					lcon.close();
				}
			}
		return res;
	}

}
