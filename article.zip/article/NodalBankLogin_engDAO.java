package com.tcs.nregs.FundFR.dao;

import java.io.IOException;
import java.sql.SQLException;
import java.util.ArrayList;

public interface NodalBankLogin_engDAO {
	public String validateLogin(String uname, String passw) throws Exception;
	public String validateGoLogin(String uname, String passw) throws Exception;
	public String validateArticleLogin(String uname, String passw) throws Exception;
	public String validateLogin1(String uname, String passw) throws Exception;
	public boolean ChangePassword(String uname, String passw, String newpassw) throws Exception;
	public boolean GoChangePassword(String uname, String passw, String newpassw) throws Exception;
	public ArrayList getExcessLimitFTRsHdngs(String roleId) throws Exception;
	public ArrayList getExcessLimitFTRs(String sid,String purpose) throws Exception;//MCC 
	public ArrayList getVRFHdngs() throws Exception;
	public ArrayList getVRFDtls(String state) throws Exception;
	public ArrayList getChenchuExcessLimitFTRs(String State) throws Exception;
	public ArrayList getDCCExcessLimitFTRs(String state,String purpose) throws Exception;
	public int ApproveFTRs(ArrayList FTRList) throws Exception;
	public int VerifyFTRs(ArrayList FTRList) throws Exception;
	public int rejectFTRs(String FTRNo,String reason) throws Exception;
	public ArrayList getFTRDtls(String FTRNo, String ptype) throws Exception;
	public ArrayList getFTRAbstract(String state,String finYear) throws Exception;
	public ArrayList getDAPExcessLimitFTRs(String state,String purpose) throws Exception;
	public ArrayList getChenchuFTRDtls(String FTRNo) throws Exception;
	public ArrayList getChenchuFTRAbstract(String state) throws Exception;
	public int ApproveChenchuFTRs(ArrayList FTRList) throws Exception;
	public int rejectChenchuFTRs(String FTRNo,String reason) throws Exception;
	public ArrayList getPurposeList(String state, String type) throws Exception;
	/*public ArrayList getPurposeListMCC() throws Exception;
	public ArrayList getPurposeListDCC() throws Exception;
	public ArrayList getPurposeListDAP() throws Exception;*/
	public ArrayList<ArrayList<String>> getGOUploadData(String year,String userName) throws IOException;
	public ArrayList<ArrayList<String>> getEditGoData(String go_number,String userName);
	public int deleteGoDetails(String sequenceNumber,String userName);
	public int setGOUploadData(String category,String gonumber,String goDate,String subject,String fname,String userName) throws Exception;
	public int updateGoData(String category,String gonumber,String goDate,String subject,String fname,String userName,String sequenceNumber);
	public ArrayList<ArrayList<String>> getMaxFileNumber(String userName,String goNumber);
	public ArrayList<ArrayList<String>> getArticleUploadData(String seqNumber) throws Exception;
	public boolean articleChangePassword(String lStrUserName, String lStrPass,String lStrPass1) throws Exception;
	public ArrayList<ArrayList<String>> getArticleMaxFileNumber(String newsPaperShortcut, String districtID) throws Exception;
	public ArrayList<ArrayList<String>> getShortcutNewspaper(String newspaperName) throws Exception;
	public int setArticleUploadData(String newspaperName, String districtName,String articleDiscription, String fname, String userName,String seqNumber) throws Exception;
}
