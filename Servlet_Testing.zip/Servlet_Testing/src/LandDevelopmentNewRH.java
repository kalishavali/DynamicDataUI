

import java.io.File;
import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.GregorianCalendar;
import java.util.List;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.apache.commons.fileupload.disk.DiskFileItemFactory;
import org.apache.commons.fileupload.servlet.ServletFileUpload;

import com.google.gson.Gson;

/**
 * Servlet implementation class LandDevelopmentNewRH
 */
public class LandDevelopmentNewRH extends HttpServlet {
	private static final long serialVersionUID = 1L;

	String lStrQuery="";
	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		String lStrAction=""; 
		if (request.getParameter("actionVal") != null) {
			lStrAction = request.getParameter("actionVal");
		}
		HttpSession session = request.getSession();
		Calendar calendar = new GregorianCalendar();
	    if (lStrAction != null && lStrAction.equals("goUpload")) {
			String category="";
			String gonumber="";
			String goDate="";
			String subject="";
			int result=0;
			String MaxFileNo="";
			String UPLOAD_DIRECTORY = "C:/Files/";
			//String UPLOAD_DIRECTORY = "\\\\10.100.100.41\\f$\\Application_Downloads\\NREGS_Web\\GO\\";
			if(!session.getAttribute("Status").equals("SUCCESS")){
				RequestDispatcher rs = request.getRequestDispatcher("goLogin.jsp");
				rs.forward(request,response);
			}
			else if (ServletFileUpload.isMultipartContent(request)) {
				try {
					String fname = null;
					String userName=(String)session.getAttribute("username");
					List<org.apache.commons.fileupload.FileItem> multiparts = new ServletFileUpload(new DiskFileItemFactory()).parseRequest(request);
					for (org.apache.commons.fileupload.FileItem item : multiparts) {
						if (!item.isFormField()) {
							ArrayList<ArrayList<String>> resultList=new ArrayList<ArrayList<String>>();
							resultList=getMaxFileNumber(userName, gonumber);
							MaxFileNo=String.format("%03d",Integer.parseInt( resultList.get(0).get(0) )+1);
							fname = new File(item.getName()).getName();
							fname = userName+"_"+gonumber+"_"+MaxFileNo+"."+fname.substring(fname.lastIndexOf(".") + 1);
							item.write(new File(UPLOAD_DIRECTORY + File.separator + fname ));
						}else if (item.isFormField() && item.getFieldName().equals("category")) {			                
							category = item.getString();			               
			            }else if (item.isFormField() && item.getFieldName().equals("gonumber")) {			                
							gonumber = item.getString();			               
			            }else if (item.isFormField() && item.getFieldName().equals("dmaDate12")) {			                
							goDate = item.getString();			               
			            }else if (item.isFormField() && item.getFieldName().equals("subject")) {			                
							subject = item.getString();			               
			            }
					}
					result=setGOUploadData(category,gonumber,goDate,subject,fname,userName);
					if(result==1){
						ArrayList<ArrayList<String>> spryearList=new ArrayList<ArrayList<String>>();
						request.setAttribute("result", "Go files uploaded Successfully");
						spryearList = getFinancialYear();
						String y=Integer.toString(calendar.get(Calendar.YEAR));
						ArrayList<ArrayList<String>> resultList=new  ArrayList<ArrayList<String>>();
						resultList = getGOUploadData(Integer.toString(calendar.get(Calendar.YEAR)),userName);
						request.setAttribute("resultList",resultList);
						request.setAttribute("yearList",spryearList);
						RequestDispatcher rs = request.getRequestDispatcher("goDetails.jsp");
						rs.forward(request,response);
					}else
					{
						request.setAttribute("result", "Failed upload Go files. Please try again");
						RequestDispatcher rs = request.getRequestDispatcher("goUpload.jsp");
						rs.forward(request,response);
					}
					
				} catch (Exception ex) {
					request.setAttribute("Error", "Failed to upload file" + ex);
				}
	 
			}else {
				request.setAttribute("Error","Failed to upload file");
				RequestDispatcher rs = request.getRequestDispatcher("goUpload.jsp");
				rs.forward(request,response);
			}
			
	    }
		if (lStrAction != null && lStrAction.equals("updateGoData")) {
			String category="";
			String gonumber="";
			String goDate="";
			String subject="";
			int result=0;
			String MaxFileNo="";
			String fname_temp=null;
			String seqNumber=request.getParameter("seqNumber");
			String fname=request.getParameter("fileName");
			String oldName=fname;
			String cmpGoNum=fname.substring(fname.indexOf("_")+1,fname.lastIndexOf("_"));
			String UPLOAD_DIRECTORY = "C:/Files/";
			//String UPLOAD_DIRECTORY = "\\\\10.100.100.41\\f$\\Application_Downloads\\NREGS_Web\\GO\\";
			if (ServletFileUpload.isMultipartContent(request)) {
				try {
					String userName=(String)session.getAttribute("username");
					//Maximum File Number
					
					List<org.apache.commons.fileupload.FileItem> multiparts = new ServletFileUpload(new DiskFileItemFactory()).parseRequest(request);
					for (org.apache.commons.fileupload.FileItem item : multiparts) {
						if (!item.isFormField()) {
							File file = new File(UPLOAD_DIRECTORY+fname);
					    	if(file.delete()){
								System.out.println(file.getName() + " is deleted!");
							}else{
								System.out.println("Delete operation is failed.");
							}
							fname_temp = new File(item.getName()).getName();
							fname = fname.substring(0,fname.lastIndexOf(".")+1)+fname_temp.substring(fname_temp.lastIndexOf(".")+1);;
							item.write(new File(UPLOAD_DIRECTORY + File.separator+ fname));
						}else if (item.isFormField() && item.getFieldName().equals("category")) {			                
							category = item.getString();			               
			            }else if (item.isFormField() && item.getFieldName().equals("gonumber")) {			                
							gonumber = item.getString();
							if(!gonumber.equals(cmpGoNum)){
								ArrayList<ArrayList<String>> resultList=new ArrayList<ArrayList<String>>();
								resultList=getMaxFileNumber(userName, gonumber);
								MaxFileNo=String.format("%03d",Integer.parseInt( resultList.get(0).get(0) )+1);
								fname = userName+"_"+gonumber+"_"+MaxFileNo+"."+fname.substring(fname.lastIndexOf(".") + 1);
								File oldfile =new File(UPLOAD_DIRECTORY+oldName);
								File newfile =new File(UPLOAD_DIRECTORY+fname);
								if(oldfile.renameTo(newfile)){
									System.out.println("Rename succesful");
								}else{
									System.out.println("Rename failed");
								}
							}
			            }else if (item.isFormField() && item.getFieldName().equals("godate")) {			                
							goDate = item.getString();			               
			            }else if (item.isFormField() && item.getFieldName().equals("subject")) {			                
							subject = item.getString();			               
			            }
					}
					result=updateGoData(category,gonumber,goDate,subject,fname,userName,seqNumber);
					PrintWriter out = response.getWriter();
					String json = new Gson().toJson(result);
			        out.println(json.toString());
			        out.close();
					
				} catch (Exception ex) {
					request.setAttribute("Error", "Failed to upload file" + ex);
				}
	 
			}else {
				request.setAttribute("Error","Failed to upload file");
				
			}
			
	    }
		if (lStrAction != null && lStrAction.equals("displayGoDetails")) {
			String userName=(String)session.getAttribute("username");
			ArrayList<ArrayList<String>> spryearList = new  ArrayList<ArrayList<String>>();
				spryearList=getFinancialYear();
			
			ArrayList<ArrayList<String>> resultList=new  ArrayList<ArrayList<String>>();
			resultList = getGOUploadData(Integer.toString(calendar.get(Calendar.YEAR)),userName);
			request.setAttribute("resultList",resultList);
			request.setAttribute("yearList",spryearList);
			RequestDispatcher rs = request.getRequestDispatcher("goDetails.jsp");
			rs.forward(request,response);
		}
		//Ajax call for GO Details
		if (lStrAction != null && lStrAction.equals("goDetails")) {
			String year = request.getParameter("year");
			String userName=(String)session.getAttribute("username");
			PrintWriter out = response.getWriter();
	        response.setContentType("text/html");
	        response.setHeader("Cache-control", "no-cache, no-store");
	        response.setHeader("Pragma", "no-cache");
	        response.setHeader("Expires", "-1");

	        response.setHeader("Access-Control-Allow-Origin", "*");
	        response.setHeader("Access-Control-Allow-Methods", "POST");
	        response.setHeader("Access-Control-Allow-Headers", "Content-Type");
	        response.setHeader("Access-Control-Max-Age", "86400");
	        
	        ArrayList<ArrayList<String>> resultList=new  ArrayList<ArrayList<String>>();
	        resultList = getGOUploadData(year,userName);
	        String json = new Gson().toJson(resultList);
	        out.println(json.toString());
	        out.close();
		}
		if (lStrAction != null && lStrAction.equals("goEdit")) {
			String sequenceNumber = request.getParameter("sequenceNumber");
			String userName=(String)session.getAttribute("username");
			PrintWriter out = response.getWriter();
	        response.setContentType("text/html");
	        response.setHeader("Cache-control", "no-cache, no-store");
	        response.setHeader("Pragma", "no-cache");
	        response.setHeader("Expires", "-1");

	        response.setHeader("Access-Control-Allow-Origin", "*");
	        response.setHeader("Access-Control-Allow-Methods", "POST");
	        response.setHeader("Access-Control-Allow-Headers", "Content-Type");
	        response.setHeader("Access-Control-Max-Age", "86400");
	        
	        ArrayList<ArrayList<String>> resultList=new  ArrayList<ArrayList<String>>();
	        resultList = getEditGoData(sequenceNumber,userName);
	        String json = new Gson().toJson(resultList);
	        out.println(json.toString());
	        out.close();
		}
		if (lStrAction != null && lStrAction.equals("deleteGoDetails")) {
			String sequenceNumber = request.getParameter("seqNumber");
			String userName=(String)session.getAttribute("username");
			PrintWriter out = response.getWriter();
	        response.setContentType("text/html");
	        response.setHeader("Cache-control", "no-cache, no-store");
	        response.setHeader("Pragma", "no-cache");
	        response.setHeader("Expires", "-1");

	        response.setHeader("Access-Control-Allow-Origin", "*");
	        response.setHeader("Access-Control-Allow-Methods", "POST");
	        response.setHeader("Access-Control-Allow-Headers", "Content-Type");
	        response.setHeader("Access-Control-Max-Age", "86400");
	        
	        int result=0;
	        result = deleteGoDetails(sequenceNumber,userName);
	        String json = new Gson().toJson(result);
	        out.println(json.toString());
	        out.close();
		}
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
	}
	public ArrayList<ArrayList<String>> getMaxFileNumber(String userName, String goNumber) {
		ArrayList<ArrayList<String>> resultList=new ArrayList<ArrayList<String>>();
		ArrayList<String> subList=new ArrayList<String>();
		try{
			Class.forName("oracle.jdbc.driver.OracleDriver");
	    	Connection con=DriverManager.getConnection("jdbc:oracle:thin:@10.138.134.107:1521:webdev","apregs_admin","apregs_admin");
	    	Statement stmt=con.createStatement();
	   	 	ResultSet res = stmt.executeQuery("SELECT --SUBSTR(W.FILE_NAME,1,4),SUBSTR(W.FILE_NAME,1,INSTR(W.FILE_NAME,'.',1,REGEXP_COUNT(W.FILE_NAME,'[.]'))-5),\n" +
					"NVL(TO_NUMBER(MAX(SUBSTR(SUBSTR(W.FILE_NAME,1,INSTR(W.FILE_NAME,'.',1,REGEXP_COUNT(W.FILE_NAME,'[.]'))-1),-3))),0) A\n" + 
					"FROM UPLOAD_GOS_DATA  W\n" + 
					"WHERE SUBSTR(W.FILE_NAME,1,4) IN ('"+userName+"')\n" + 
					"AND SUBSTR(W.FILE_NAME,1,INSTR(W.FILE_NAME,'.',1,REGEXP_COUNT(W.FILE_NAME,'[.]'))-5) = '"+userName+"_"+goNumber+"'\n" + 
					"--GROUP BY SUBSTR(W.FILE_NAME,1,4),SUBSTR(W.FILE_NAME,1,INSTR(W.FILE_NAME,'.',1,REGEXP_COUNT(W.FILE_NAME,'[.]'))-5)");
	       	while(res.next()){
	       		subList=new ArrayList<String>();
	       		subList.add(res.getString(0));
	       		resultList.add(subList);
	       	}
		}
		catch(Exception e){
			System.out.println(e);
		}
		return resultList;
	}
	public int setGOUploadData(String category, String gonumber, String goDate,
			String subject, String fname, String userName) {
		int count=0;
		try{
			Class.forName("oracle.jdbc.driver.OracleDriver");
	    	Connection con=DriverManager.getConnection("jdbc:oracle:thin:@10.138.134.107:1521:webdev","apregs_admin","apregs_admin");
	    	Statement stmt=con.createStatement();
	   	 	ResultSet res = stmt.executeQuery("insert into UPLOAD_GOS_DATA (category,go_number,go_date,subject,file_name,user_name,upload_Date,SEQUENCE_NO,IS_DELETE) values ('"+category+"','"+gonumber+"','"+goDate+"','"+subject+"','"+fname+"','"+userName+"',sysdate,UPLOAD_GOS_SEQ.NEXTVAL,'N')");
	       	while(res.next()){
	       	}
		}
		catch(Exception e){
			System.out.println(e);
		}
		return count;
	}
	public ArrayList getFinancialYear()
	  {
	             Calendar calendar=Calendar.getInstance();
	             int  ldate=calendar.get(Calendar.DATE);
	             int  lmonth=calendar.get(Calendar.MONTH);
	             int  lyear=calendar.get(Calendar.YEAR);
	       // System.out.println("lyear"+lyear);
	             lmonth=lmonth+1;
	             String lStrDate = Integer.toString(ldate);
	             String lStrMonth = Integer.toString(lmonth);
	             String lStrYear = Integer.toString(lyear);
	             ArrayList yearlist=new ArrayList();
	             if(lmonth<=3)
	             {
	             for(int i=lyear;i>=2006;i--)
	              {
	                ArrayList alist=new ArrayList();
	                alist.add( Integer.toString(i-1));
	                alist.add( Integer.toString(i-1)+"-"+Integer.toString(i));
	                yearlist.add(alist);
	              }
	             }
	             else
	             {
	             for(int i=lyear+1;i>=2006;i--)
	              {
	                ArrayList alist=new ArrayList();
	                alist.add( Integer.toString(i-1));
	                alist.add( Integer.toString(i-1)+"-"+Integer.toString(i));
	                yearlist.add(alist);
	              }
	             }
	            //  System.out.println("yearlist"+yearlist);
	              return yearlist;
	  }
	public ArrayList<ArrayList<String>> getGOUploadData(String year, String userName){
		ArrayList<ArrayList<String>> resultList=new ArrayList<ArrayList<String>>();
		try{
			Class.forName("oracle.jdbc.driver.OracleDriver");
	    	Connection con=DriverManager.getConnection("jdbc:oracle:thin:@10.138.134.107:1521:webdev","apregs_admin","apregs_admin");
	    	Statement stmt=con.createStatement();
	    	if(userName!=null){
				lStrQuery = "select TO_CHAR(TO_DATE(go_date,'DD-MM-YYYY'),'DD-Mon-YYYY'),go_number,subject,file_name,SEQUENCE_NO from UPLOAD_GOS_DATA where TO_CHAR(TO_DATE(go_date,'DD-MM-YYYY'),'YYYY')='"+year+"' AND user_name='"+userName+"' AND IS_DELETE='N' order by go_date" ;
	  		}else{
	  			lStrQuery = "select TO_CHAR(TO_DATE(go_date,'DD-MM-YYYY'),'DD-Mon-YYYY'),go_number,subject,file_name,SEQUENCE_NO from UPLOAD_GOS_DATA where TO_CHAR(TO_DATE(go_date,'DD-MM-YYYY'),'YYYY')='"+year+"' AND IS_DELETE='N' order by go_date";
	  		}
	   	 	ResultSet res = stmt.executeQuery(lStrQuery);
	       	while(res.next()){
	       	}
		}
		catch(Exception e){
			System.out.println(e);
		}
		return resultList;
	}
	public int updateGoData(String category, String gonumber, String goDate,
			String subject, String fname, String userName, String sequenceNumber) {
		int count=0;
		try{	
			Class.forName("oracle.jdbc.driver.OracleDriver");
	    	Connection con=DriverManager.getConnection("jdbc:oracle:thin:@10.138.134.107:1521:webdev","apregs_admin","apregs_admin");
	    	Statement stmt=con.createStatement();
				lStrQuery = "update UPLOAD_GOS_DATA set category='"+category+"',go_number='"+gonumber+"',go_date='"+goDate+"', subject='"+subject+"', file_name='"+fname+"', upload_Date=sysdate where user_name='"+userName+"' and SEQUENCE_NO='"+sequenceNumber+"' " ;
				ResultSet res = stmt.executeQuery(lStrQuery);
		       	while(res.next()){
		       	}
		}catch(Exception e) {
			e.printStackTrace();
		}
		return count;
	}
	public ArrayList<ArrayList<String>> getEditGoData(String sequence_Number,
			String userName) {
		ArrayList<ArrayList<String>> resultList=new ArrayList<ArrayList<String>>();
		try{	
				lStrQuery = "select category,go_number,subject,go_date,file_name from UPLOAD_GOS_DATA where SEQUENCE_NO='"+sequence_Number+"' AND user_name='"+userName+"' order by go_date" ;
		  		
		}catch(Exception e) {
			e.printStackTrace();
		}
		return resultList;
	}
	public int deleteGoDetails(String sequenceNumber,
			String userName) {
		int count=0;
		try{	
				lStrQuery = "update UPLOAD_GOS_DATA set IS_DELETE='Y',upload_Date=sysdate where user_name='"+userName+"' AND SEQUENCE_NO='"+sequenceNumber+"' " ;
			
		}catch(Exception e) {
			e.printStackTrace();
		}
		return count;
	}

}
