function search(){
	var no = document.getElementById('input2').value;
	//alert('no. is '+no);
	//alert('no. length is '+no.length);
	//alert("selected "+document.getElementById('spl').value); 
	var slctd = document.getElementById('spl').value;
	if(slctd=='Select'){
		alert('Please select the type of data to check');
		return false;		
	} 
	else if(slctd=='EPO'){ 
		if(no.length==16){
			window.open('FrontServlet?requestType=SmartCardreport_engRH&actionVal=SearchEPO&EPO_No='+no);
		}
		else if(no.length==11||no.length==13){
			window.open('FrontServlet?requestType=SmartCardreport_engRH&actionVal=SearchEPO1113&EPO_No='+no);
		}
		else{
			alert('Please Enter e-PayOrder No length - 16/11 Digit / FTR No length - 13Digit');
			return false;
		}		
	}
	else if(slctd=='FTO'){
		if(no.length!=13){
			alert('Please Enter FTR No length - 13Digit');
			return false;
		} 
		else{
			window.open('FrontServlet?requestType=CFMSReports_engRH&actionVal=SearchFTO&FTO_No='+no);
		}
	}
	else if(slctd=='JOB'){
		if(no.length!=18){
			alert('Please Enter JobCardID length - 18Digit');
			return false;
		} 
		else{
			if(no.substr(0,2)<'14')
			{
				window.open('FrontServlet?requestType=HouseholdInf_engRH&actionVal=SearchJOB&JOB_No='+no);
			}
		else
			{
			alert('Please Enter AP JobCardID length - 18Digit');
			
			}
			
			
		}
	}
	else if(slctd=='WORK'){
		if(no.length!=18){
			alert('Please Enter Work Code length - 18Digit');
			return false;
		} 
		else{
			 if(no.substr(0,2)<'14' )
			{
				window.open('FrontServlet?requestType=HouseholdInf_engRH&actionVal=SearchWorkCode&Work_No='+no);
			}
			 
			else
			{
			alert('Please Enter AP Work Code length - 18Digit');
			
			}
			
			
		} 
	}
	else if(slctd=='UID'){
		if(no.length!=12){
			alert('Please Enter UID length - 12Digit');
			return false;
		} 
		else
			{
				window.open('FrontServlet?requestType=HouseholdInf_engRH&actionVal=SearchJOB&UID_No='+no);
			}
		
			
			
		
	}
	else if(slctd=='SEARCH'){
			window.open('FrontServlet?requestType=Common_Ajax_engRH&actionVal=Display&page=Searchbyname');
		
	}
	else if(slctd=='payOrderSearch'){
		window.open('FrontServlet?requestType=Common_Ajax_engRH&actionVal=payorderDisplay&page=SearchByPayorder');
	
	}
};
$(document).ready(function() {      
	$('#spl').change(function(){      
	if($('#spl').val() === 'SEARCH' || $('#spl').val() === 'payOrderSearch')      
	   {      
	   $('#input2').hide();       
	   }      
	else     
	   {      
	   $('#input2').show();         
	   }      
	});      
	});  
function spl(){
	var slctd = document.getElementById('spl').value;
	if(slctd=='Select'){
		return false;		
	}
	else{
		search(document.getElementById('input2').value);
	}
};
document.write (

		"<table width='100%' border='0' cellspacing='0' cellpadding='0'"+
		"      align='center'>"+ 
		"      <tr>"+ 
		"        <td><table width='100%' border='0' cellspacing='0'"+ 
		"            cellpadding='0'>"+ 
		"            <tr>"+ 
		"              <td class='scrol-ln' height='0'></td>"+ 
		"            </tr>"+ 
		"            <tr>"+ 
		"              <td bgcolor='#f1f0f0'"+ 
		"                style='padding: 5px; padding-top: 8px; padding-left: 15px;'><table"+ 
		"                  width='100%' border='0' cellspacing='2' cellpadding='0'>"+ 
		"                  <tr>"+ 
		"                    <td colspan='3' width='45%' align='left' valign='top'"+ 
		"                      class='foot-hd-txt'"+ 
		"                      style='border-bottom: 1px #666666 solid; height: 20px;'>Portals"+ 
		"                      and Related Links</td>"+ 
		"                    <td width='15%' align='left' valign='top'"+ 
		"                      class='foot-hd-txt'"+ 
		"                      style='border-bottom: 1px #666666 solid; height: 20px;'>"+ 
		"                      NREGS Logins</td>"+ 
		"                    <td width='40%' align='left' valign='top'"+ 
		"                      class='foot-hd-txt'"+ 
		"                      style='border-bottom: 1px #666666 solid; height: 20px;'>"+ 
		"                      Personal Customize</td>"+ 
		"                  </tr>"+ 
		"                  <tr>"+ 
		"                    <td width='15%' align='left' valign='top' style='border-left:1px #CCCCCC solid; line-height:25px; padding-left:7px;'>"+ 
		"                      <!-- Column 1 Starts --> " + 
		"                      <a href='http://125.17.121.164/CLDP'"+ 
		"                      class='blk-lnk'>CLDP</a><br />"+
		"                      <a href='#'"+  
		"                      class='blk-lnk'>Field Assistants</a><br /> " +
		"                      <a href='/Nregs/Tenders.jsp'"+ 
	    "                      class='blk-lnk'>Tenders</a> <br /> " +
	    "                      <a href='http://emuster.in'"+ 
		"                      class='blk-lnk'>eMMS</a><br /> " +
		"					   <!-- Column 1 Ends -->"+ 
		"                    </td>"+ 
		"                    <td width='15%' align='left' valign='top' style='border-left:1px #CCCCCC solid; line-height:25px; padding-left:7px;'>"+ 
		"                      <!-- Column 2 Starts --> <a href='http://www.rd.ap.gov.in/'"+ 
		"                      class='blk-lnk'>RD Ministry, AP</a><br /> <a"+ 
		"                      href='http://rural.nic.in/' class='blk-lnk'>RD"+ 
		"                        Ministry, GoI</a><br /> <a"+ 
		"                      href='http://nrega.nic.in/netnrega/home.aspx'"+ 
		"                      class='blk-lnk'>MGNREGA - NIC</a><br /> <a"+  
		"                      href='http://www.rdcallcentre.ap.gov.in/main.do'"+ 
		"                      class='blk-lnk'>RD Call Center</a> <!-- Column 2 Ends -->"+ 
		"                    </td>"+ 
		"                    <td width='15%' align='left' valign='top' style='border-left:1px #CCCCCC solid; line-height:25px; padding-left:7px;'>"+ 
		"                      <!-- Column 3 Starts --> <a"+ 
		"                      href='http://www.aponline.gov.in/apportal/index.asp'"+ 
		"                      class='blk-lnk'>AP Online</a><br /> <a"+ 
		"                      href='https://www.serp.ap.gov.in/SHG/index.jsp'"+ 
		"                      class='blk-lnk'>SERP</a><br />  <a"+ 
		"                      href='#' class='blk-lnk'>e"+ 
		"                        Tenders</a><br /> <a"+ 
		"                      href='http://rdcallcentre.ap.gov.in/nregs.do?method=createComplaint'"+ 
		"                      class='blk-lnk'>e Complaints</a><br /> " +
		"                    </td>"+ 
		"                    <td width='15%' align='left' valign='top'"+ 
		"                      style='border-left:1px #CCCCCC solid; line-height:25px; padding-left:7px;'><a"+ 
		"                      href='http://125.17.121.164/QC/index.jsp' class='blk-lnk'>P.D"+ 
		"                        Login</a><br /> <a"+ 
		"                      href='/Nregs/NodalbankLogin.jsp' class='blk-lnk'>Nodal Bank Login"+
		"                        </a><br /> <a"+ 
		"                      href='/Nregs/SmartCardLogin.jsp' class='blk-lnk'>Smart Card Login" +
		"                        </a><br /><a"+ 
		"                      href='/Nregs/goLogin.jsp' class='blk-lnk'>Admin Login" +
		"                        </a><br /><a href='http://125.17.121.165/ITSAP/'"+ 
		"                      class='blk-lnk'>Request tracking system</a><br /> </td>"+ 
		"                    <td align='left' valign='top' width='40%'  style='border-left:1px #CCCCCC solid; line-height:25px; padding-left:7px;'>"+ 
		"                      <table width='100%' border='0' cellspacing='0'"+ 
		"                        cellpadding='0'>"+ 
		"                        <tr>"+ 
		"                          <td width='32%' align='left' valign='top' class='blk-lnk'"+ 
		"                            style='line-height: 25px; text-decoration: none; '>"+ 
		"                            Color Theme<br /> <!-- <a href='javascript:chooseStyle('blue='Blue'', 60)' checked='checked'> <img src='images/thm-1-Ico.jpg' border='0' alt='blue color theme' /></a>&nbsp;&nbsp;"+ 
		"              <a href='javascript:chooseStyle('green='Green'', 60)' checked='checked'> <img src='images/thm-2-Ico.jpg' border='0' /></a>&nbsp;&nbsp;"+ 
		"              <a href='javascript:chooseStyle('nregs-style='Nregs-Style'', 60)'> <img src='images/thm-3-Ico.jpg' border='0' /></a>&nbsp;&nbsp;"+ 
		"              <a href='#'> <img src='images/thm-4-Ico.jpg' border='0' /></a>&nbsp;&nbsp;"+ 
		"              <a href='#'> <img src='images/thm-5-Ico.jpg' border='0' /></a>&nbsp;&nbsp;  -->"+ 
		"                            <a class='styleswitch' href='#' rel='styles1'> <img"+ 
		"                              src='images/thm-1-Ico.jpg' onclick='javascript:changeDisbursementGraphColours(\"#5D4984\")' border='0' />"+ 
		"                          </a> <a class='styleswitch' href='#'"+ 
		"                            rel='styles2'> <img src='images/thm-2-Ico.jpg' onclick='javascript:changeDisbursementGraphColours(\"#786101\")'"+ 
		"                              border='0' />"+ 
				
		"                          </a> <a class='styleswitch' href='#'"+ 
		"                            rel='styles3'> <img src='images/thm-3-Ico.jpg' onclick='javascript:changeDisbursementGraphColours(\"#864086\")'"+ 
		"                              border='0' /> "+
		
		 " 								</a> <a class='styleswitch' href='#'"+ 
		"                            rel='styles4'> <img src='images/thm-4-Ico.jpg' onclick='javascript:changeDisbursementGraphColours(\"#00C14E\")'"+ 
		"                              border='0' /> "+
		
		"                         <br> <a   class='blk-lnk' href='/Nregs/Maps.jsp'>Map</a><br>"+
		"<b> Select Font :</b>&nbsp;"+
		"							<a class='styleswitch' href='#' id='a' rel='fontstyles1' style='text-decoration:none; font-size:8px; color:Black'><sub>-</sub>A</a>&nbsp;"+
		"							<a class='styleswitch' href='#' id='11px' rel='styles1' style='text-decoration:none; font-size:11px; color:Black'>A</a>&nbsp;" +
		"							<a class='styleswitch' href='#' id='14px' rel='fontstyles2' style='text-decoration:none; font-size:14px; color:Black'>A<sup>+</sup></a>&nbsp;</br>" +		
		"							</td>"+ 
		"                          <td align='left' valign='top' class='blk-lnk'"+ 
		"                            style='border-left:1px #CCCCCC solid; line-height:25px; padding-left:7px;'>looking for something<br />"+ 
		"                            <select name='spl' id='spl' >"+ 
		"                              <option value='Select'>Select</option>"+ 
		"                              <option value='EPO'>ePayorder Status</option>"+ 
		"                              <option value='FTO'>FTO Status</option>"+ 
		"							   <option value='JOB'>JobCard</option>"+ 
		"							   <option value='SEARCH'>Search by Name</option>"+ 
		"							   <option value='payOrderSearch'>Pay Order</option>"+
		"							   <option value='WORK'>Work ID</option>"+
		"							   <option value='UID'>UID</option>"+
		"							</select>" +
		"							 <input name='input2' id='input2' type='text'/>"+
		" <button  id='go' name='Go' style='width: 59px; height: 23px' onClick='search();'> Go</button>"+
		"                 		 <tr>"+ 
		"                          <td width='68%' align='left' valign='top' class='blk-lnk'"+ 
		"                            style='line-height: 20px;'>&nbsp;&nbsp;</td>"+
		"                          <td align='left' valign='top' class='blk-lnk'"+ 
		"                            style='line-height: 20px; padding-top: 5px; padding-left:7px; text-decoration: none; border-left:1px #CCCCCC solid;'>Select"+ 
		"                            Language&nbsp;&nbsp;"+ 
		"                            <div id='google_translate_element' align='left'></div>"+ 
		"                          </td>"+ 
		"                        </tr>"+ 
		"                      </table>"+ 
		"                    </td>"+ 
		"                  </tr>"+ 
		"                  <tr>"+ 
		"                    <td colspan='5'>"+ 
		"                      <table cellpadding='0' cellspacing='0' border='0'"+ 
		"                        width='100%'>"+ 
		"                        <tr>"+ 
		"                          <td align='left' valign='top' class='blk-lnk'"+ 
		"                            style='line-height: 30px;'></td>"+ 
		                      
		"                          <td align='right' valign='middle' colspan='3'>"+ 
		"                            <table border='0' cellspacing='0' cellpadding='0'>"+ 
		"                              <tr>"+ 
		"                                <td>"+ 
		"                                  <table cellpadding='0' cellspacing='0' border='0'"+ 
		"                                    class='cntc-icon-bdr'>"+ 
		"                                    <tr>"+ 
		"                                      <td align='left' valign='middle'"+ 
		"                                        style='padding: 5px; font-weight: bold;'><img"+ 
		"                                        src='images/PHN-ICON.png' />"+ 
		"                                      </td>"+ 
		"                                      <td align='left' valign='middle'"+ 
		"                                        style='padding: 5px; vertical-align: middle; font-weight: bold;'>Praja Samasyala Parishkaara Vedika<br>"+ 
		"                                       MEEKOSAM-1100-1800-425-4440</td>"+ 
		"                                    </tr>"+ 
		"                                  </table></td>"+ 
		"                                <td><a href='http://www.facebook.com/APMGNREGA'"+ 
		"                                  target='_blank'>&nbsp;<img"+ 
		"                                    src='images/FB-ICON.png' border='0' />"+ 
		"                                </a>"+ 
		"                                </td>"+ 
		"                                <td>&nbsp;</td>"+ 
		"                              </tr>"+ 
		"                            </table>"+ 
		"                          </td>"+ 
		"                        </tr>"+ 
		"                      </table></td>"+ 
		"                  </tr>"+ 
		"                </table>"+ 
		"              </td>"+ 
		"            </tr>"+ 
		"            <tr>"+ 
		"              <td height='5'></td>"+ 
		"            </tr>"+ 
		"            <tr>"+ 
		"              <td bgcolor='#f1f0f0'"+ 
		"                style='padding-right: 5px; padding-left: 5px;'><table"+ 
		"                  border='0' cellspacing='0' cellpadding='0' align='right'"+ 
		"                  width='100%'>"+ 
		"                  <tr>"+ 
		"                    <td width='62%' valign='middle'"+ 
		"                      style='font-size: 11px; font-weight: 800; text-align: left; color: #000; vertical-align: middle;'>"+ 
		"                      Contents provided by Department of Rural Development, Govt. of Andhra Pradesh.</td>"+ 
		"                    <td width='13%' valign='middle'"+ 
		"                      style='font-size: 11px; font-weight: 800; color: #000; vertical-align: middle;'>"+ 
		"                      Designed, Developed &amp; Maintained by</td>"+ 
		"                    <td width='25%' valign='middle'><a"+ 
		"                      href='http://www.tcs.com/Pages/default.aspx'"+ 
		"                      target='_blank'> <img border='0'"+ 
		"                        src='images/TCS-Logo.png' width='267' height='25'"+ 
		"                        alt='TATA CONSULTANCY SERVICES LOGO' />"+ 
		"                    </a>"+ 
		"                    </td>"+ 
		"                  </tr>"+ 
		"                </table>"+ 
		"              </td>"+ 
		"            </tr>"+ 
		"          </table>"+ 
		"        </td>"+ 
		"      </tr>"+ 
		"    </table>"
);