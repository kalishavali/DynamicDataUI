document.write (
	"	<table width='100%' border='0' cellspacing='0' cellpadding='0'>"+
	"	<tr>"+
	"		<td height='25' colspan='3' align='right' valign='middle'>" +
	" 			<a href='/Nregs/Home_eng.jsp' class='top-mini-lnk'>Home</a>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;"+
	"			<a href='/Nregs/sitemap_eng.htm' class='top-mini-lnk'>Sitemap</a>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;"+
	"			<a href='/Nregs/ContactUs_eng.jsp' class='top-mini-lnk'>Contact Us</a>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;"+
	"			<a href='/Nregs/FrontServlet?requestType=Feedback_engRH&type=public' class='top-mini-lnk'>Feedback</a>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;"+
	"		</td>"+
	"	</tr>"+
	"	<tr>"+
	"		<td align='left' valign='middle'><img"+
	"			src='NREGS-LOGO.png' width='148' height='110'"+
	"			alt='NREGS LOGO' />"+
	"		</td>"+
	"		<td align='center' valign='middle' class='hd-txt'>&nbsp;</td>"+
	"		<td align='right' valign='middle'><img"+
	"			src='MGNREGS-LOGO.png' width='130' height='100'"+
	"			alt='MGNREGS LOGO' />"+
	"		</td>"+
	"	</tr>"+
	"	<tr>"+
	"		<td height='28' colspan='3'"+
	"			style='background-image: url(Menu-bg.png)'>"+
	"			<table cellpadding='0' cellspacing='0' border='0' width='100%'>"+
	"				<tr>"+
	"					<td align=left valign=middle width='40%'"+
	"						style='padding-left: 5px;'>"+
	"						<div id='myslidemenu' class='jqueryslidemenu'"+
	"							style='float: left;'>"+
	"							<ul>"+
	"								<li><a href='#'>MGNREGS</a>"+
	"									<ul>"+
	"										<li><a href='/IGRS/About.html'>NREG-Act/Guidelines</a>"+
	"											<ul>"+
	"												<li><a"+
	"													href='/Nregs/LoadDocument?docName=GovtDocs\\NREGAct Sep 2005.pdf' target='blank'>NREGS"+
	"														Act</a>"+
	"												</li>"+
	"												<li><a"+
	"													href='/Nregs/LoadDocument?docName=GovtDocs\\NREGA rules_ By Laws.pdf' target='blank'>Rules"+
	"														and by Laws</a>"+
	"												</li>"+
	"												<li><a"+
	"													href='/Nregs/LoadDocument?docName=GovtDocs\\NREGAOperationalGuidelines.pdf' target='blank'>operational"+
	"														Guidelines</a>"+
	"												</li>"+
	"											</ul>"+
	"										</li>"+
	"										<li><a href='/IGRS/Under-Const.html'>Notifications,GOs,Circulars etc.,</a>"+
	"											<ul>"+
	"												<li><a href='/Nregs/LoadDocument?docName=GovtDocs\\apregscheme.htm' target='blank'>MGNREGS-AP"+
	"														Scheme</a>"+
	"												</li>"+
	"												<li><a"+
	"													href='/Nregs/LoadDocument?docName=GovtDocs\\Gazzette_notification_of_new_schedule_IandII_18012014.pdf' target='blank'>Gazette"+
	"														Notifications</a>"+
	"												</li>"+
	"												<li><a"+
	"													href='/Nregs/FrontServlet?requestType=LandDevelopmentNewRH&actionVal=displayGoDetails'"+
	"													target='_blank'>GOs, Memos and Circulars</a>"+
	"												</li>"+
	"												<li><a"+
	"													href='/Nregs/LoadDocument?docName=GovtDocs\\Annual Report 2006.pdf' target='blank'>Evaluation"+
	"														Studies</a>"+
	"												</li>"+
													
	"												<li><a"+
	"													href='/Nregs/LoadDocument?docName=GovtDocs\\Wage_Payment_through_Post_Offices.ppt' target='blank'>Wages"+
	"														through Post Offices</a>"+
	"												</li>"+
													
	"											</ul>"+
	"										</li>"+
	"										<li><a href='/IGRS/Under-Const.html'>MGNREGS Works</a>"+
	"											<ul>"+
	"												<li><a"+
	"													href='/Nregs/FrontServlet?requestType=NewReportsRH&actionVal=Work_Task_Display&page=Work_Task'>Work's"+
	"														task sheet</a>"+
	"												</li>"+
	"												<li><a href='/Nregs/WorksList.jsp'>List Of"+
	"														Works/Diagrams</a>"+
	"												</li>"+
	"                                                <li><a href='/Nregs/SSR_eng.jsp' target='_blank'>Rural"+
	"														Std schedule of rates</a>"+
	"												</li>"+
	"											</ul>"+
	"										</li>"+
	"										<li><a href='/IGRS/Under-Const.html'>Evaluation"+
	"												Studies</a>"+
	"											<ul>"+
	"												<li><a"+
	"													href='/Nregs/LoadDocument?docName=GovtDocs\\Impact on Agriculture.pdf' target='blank'>Impact"+
	"														on Agriculture</a>"+
	"												</li>"+
	"												<li><a href='/Nregs/LoadDocument?docName=GovtDocs\\CMSA_REPORT.doc'>CMSA"+
	"														Report</a>"+
	"												</li>"+
	"												<li><a"+
	"													href='/Nregs/LoadDocument?docName=GovtDocs\\Impact_of_NREGS.pdf' target='blank'>Impact"+
	"														on Children's Education</a>"+
	"												</li>"+
	"												<li><a"+
	"													href='/Nregs/LoadDocument?docName=GovtDocs\\NREGS_Poverty.pdf' target='blank'>Impact"+
	"														on Poverty</a>"+
	"												</li>"+
	"											</ul>"+
	"										</li>"+
	"										<li><a href='/IGRS/Under-Const.html'>Person with"+
	"												Disability</a>"+
	"											<ul>"+
	"												<li><a"+
	"													href='/Nregs/LoadDocument?docName=GovtDocs\\Mate Module for VSSS Groups Mates.pdf' target='blank'>Shrama"+
	"														Mithra's training document</a>"+
	"												</li>"+
	"												<li><a"+
	"													href='/Nregs/FrontServlet?requestType=NewReportsRH&actionVal=circularAndGosRep&page=CircularAndGosReport' >Circular/GO's"+
	"														Reports</a>"+
	"												</li>"+
	"											</ul>"+
	"										</li>"+
	"										<li><a href='/IGRS/Under-Const.html'>MGNREGS"+
	"												Software</a>"+
	"											<ul>"+
	"												<!-- <li><a href='/Nregs/GovtDocs/Process Flow Diagrams.htm' target='_blank'>Process Flow Diagram </a></li>-->"+
	"												<li><a"+
	"													href='#'"+
	"													target='_blank'>Process Flow Diagram </a>"+
	"												</li>"+
	"												<li><a"+
	"													href='/Nregs/LoadDocument?docName=GovtDocs\\APREGS Module wise write up.doc'" +
	"                                                        target='_blank'>Modules Wise Write Up</a>"+
	"												</li>"+
	"												<li><a"+
	"													href='/Nregs/LoadDocument?docName=GovtDocs\\APEGS User Manual 22nd April 2006.doc' target='blank'>User"+
	"														Manuals</a>"+
	"												</li>"+
	"												<li><a"+
	"													href='/Nregs/LoadDocument?docName=GovtDocs\\Prl_secy_RD_AP_28th_Dec.ppt' target='blank'>MGNREGS-AP"+
	"														Overview</a>"+
	"												</li>"+
	"												<li><a"+
	"													href='/Nregs/LoadDocument?docName=GovtDocs\\New Minister Presentation on RD.pdf' target='blank'>MGNREGS"+
	"														Presentation</a></li>"+
	"											</ul>"+
	"										</li>"+
	"									</ul>"+
	"								</li>" +
	"								<li><a href='#'>Important Links</a>" +
	"									<ul>" +
	"										<li><a href='/Nregs/FrontServlet?requestType=LandDevelopmentRH&actionVal=Hudhud' target='_blank' >" +
	"											Cutting and Removal of Damaged Horticulture Plants in Farmers Fields in Hudhud affected Villages</a>" +
	"										</li>" +
	"										<li><a href='/Nregs/FrontServlet?requestType=LandDevelopmentRH&actionVal=NBAProjectRpt' target='_blank'>" +
	"											Nirmal Bharat Abhiyan Project - Work Status Report (EGS + RWS Funding)</a>" +
	"										</li>" +
	"										<li><a href='/Nregs/FrontServlet?requestType=HorticultureRH&actionVal=ipt' target='_blank'>" +
	"											Indiramma Pachha Toranam</a>" +
	"										</li>" +
	"										<li><a href='/Nregs/FrontServlet?requestType=DemandRH&actionVal=DmndWeeklyRptNew&btype=allbatch2&repName=homerep' target='_blank'>" +
	"											Demand Allocation</a>" +
	"										</li>" +
	"										<li><a href='/Nregs/FrontServlet?requestType=SpecialReportsRH&actionVal=DCSRpt&type=New&Linktype=CUMULATIVE' target='_blank'>" +
	"											Delay Compensation</a>" +
	"										</li>" +
	"										<li><a href='/Nregs/FrontServlet?requestType=SpecialReportsRH&actionVal=WorkStatus&type=R19.1' target='_blank'>" +
	"											Assets</a>" +
	"										</li>" +
	"										<li><a href='/Nregs/FrontServlet?requestType=Common_Ajax_engRH&actionVal=Display&page=Smartreports_eng' target='_blank'>" +
	"											DBT Reports</a>" +
	"										</li>" +
	"										<li><a href='/Nregs/FrontServlet?requestType=Common_Ajax_engRH&actionVal=Display&page=Hortireportcenter_eng' target='_blank'>" +
	"											Horticulture Reports</a>" +
	"										</li>" +
	"									</ul>" +
	"								</li>" +
	"								<li><a href='#'>Smart Links</a>" +
	"									<ul>" +
	"										<li><a href='/Nregs/FrontServlet?requestType=NewReportsRH&actionVal=AllGlance' target='_blank'>" +
	"											MGNREGS-AP a Glance Report</a>" +
	"										</li>" +
	"										<li><a href='/Nregs/FrontServlet?requestType=NewReportsRH&actionVal=CRDR1' target='_blank'>" +
	"											The monthly progress of MGNREGS-AP</a>" +
	"										</li>" +
	"										<li><a href='/Nregs/FrontServlet?requestType=NewReportsRH&actionVal=Abstract' target='_blank'>" +
	"											MGNREGS-AP Abstract Report</a>" +
	"										</li>" +
	"										<li><a href='/Nregs/FrontServlet?requestType=LandDevelopmentRH&actionVal=NBAProjectRpt' target='_blank'>" +
	"											IHHL Report</a>" +
	"										</li>" +
	"										<li><a href='/Nregs/FrontServlet?requestType=Common_engRH&actionVal=display&page=ConsMuster_eng' target='_blank'>" +
	"											Muster Rolls</a>" +
	"										</li>" +
	"										<li><a href='/Nregs/FrontServlet?requestType=Common_engRH&actionVal=mandal&page=MusterRolls_eng&chkstate=02' target='_blank'>" +
	"											Consolidated Muster Rolls</a>" +
	"										</li>" +
	"										<li><a href='/Nregs/FrontServlet?requestType=SmartCardreport_engRH&actionVal=UIDSeedingLink&flag=UIDLink' target='_blank'>" +
	"											Day wise Aadhaar Enrollment</a>" +
	"										</li>" +
	"									</ul>" +
	"								</li>"+	
	"								<li><a"+
	"									href='/Nregs/FrontServlet?requestType=NewReportsRH&page=wagecenter_eng'>Wage"+
	"										Seekers</a></li>"+
	"								<li><a"+
	"									href='/Nregs/FrontServlet?requestType=Work_engRH&page=workcenter_eng'>Works</a>"+
	"								</li>"+
	"								<li><a"+
	"									href='/Nregs/FrontServlet?requestType=Common_engRH&actionVal=funds&page=fundreports_eng'>Financial"+
	"										Reports</a></li>"+
	"								<li><a"+
	"									href='/Nregs/FrontServlet?requestType=NewReportsRH&actionVal=Display&page=Newreportcenter_ajax_eng'>"+
	"										MIS Reports</a></li>"+
	"								<!--<li><a href='/Nregs/FrontServlet?requestType=AnalAbs_engRH&page=Analysiscenter_eng'>Analysis</a></li>-->"+
	"								<li><a href='/Nregs/FrontServlet?requestType=Common_Ajax_engRH&actionVal=Display&page=Analysiscenter_eng2'>Analysis</a></li>"+	
								
	"							</ul>"+
	"						</div>"+
	"					</td>"+
	"				</tr>"+
	"			</table>"+
	"		</td>"+
	"	</tr>"+
	" </table>"
);