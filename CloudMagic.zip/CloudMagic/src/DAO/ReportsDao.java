package DAO;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;

public interface ReportsDao {
	public ArrayList<String> getAllCommonDtls(String sid,String did,String mid,String pid,String finYear,String month) throws Exception;
	public String[] getCurrFinyearMonth() throws Exception;
	public String getMonthByNumber(String mm);
	public ArrayList getId(String id) ;
	public HashMap<String,String> getDbDistricts(String sid);
	public Map<String,String> getDbMandals(String sid,String did);
	public Map<String,String> getDbPanchayats(String sid,String did,String mid);
	public Map<String,String> getDbVillages(String sid,String did,String mid,String pid);
	
	public ArrayList getHeadings(String did,String mid,String pid);
	public  ArrayList getDataList(String did,String mid,String pid);
	
	public ArrayList getDistrictNamebyId(String sid,String did) throws Exception;
	public ArrayList getMandalNamebyId(String sid,String did,String mid) throws Exception;
	public ArrayList getPanchayatNamebyId(String sid, String did,
			String mid, String pid) throws Exception;
}
