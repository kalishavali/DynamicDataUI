package authentication;

import java.io.File;
import java.io.FileFilter;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;

import org.apache.commons.io.filefilter.WildcardFileFilter;

public class DirectoryScanner {
	public static void main(String[] args){
		SimpleDateFormat simpleDateFormat =
	        new SimpleDateFormat("dd-MMM-yyyy hh:mm:ss");
		System.out.println(new Date());
	String date = simpleDateFormat.format("18-03-2016 01:40:31 AM");
	System.out.println(date);
		ArrayList<String> list1=new ArrayList<String>();
		list1.add("Kalishavali");
		list1.add("Shaik");
		list1.set(1, "Hello");
		System.out.println(list1);
		String path="c:\\";
		String getPath="GovtDocs\\RevisitingPhotos\\1262\\121656202002003603_356.jpg";
	    String targetFolder=getPath.substring(0,getPath.lastIndexOf("\\")+1);
	    String target_file_name=getPath.substring(getPath.lastIndexOf("\\")+1);
	    String target_file=null;
		File folderToScan = new File(path+targetFolder); 
		File[] listOfFiles = folderToScan.listFiles();
	    String docName=null;
	    for (int i = 0; i < listOfFiles.length; i++) {
	            if (listOfFiles[i].isFile()) {
	                target_file = listOfFiles[i].getName();
	                if (target_file.equals(target_file_name.substring(0,target_file_name.lastIndexOf(".")))&& target_file.endsWith(target_file_name.substring(target_file_name.lastIndexOf(".")))) {
	                     System.out.println("found" + " " + target_file);
	                     docName=targetFolder+target_file;
	                }
	                else if(target_file.contains(target_file_name.substring(0,target_file_name.lastIndexOf(".")))&& target_file.endsWith(target_file_name.substring(target_file_name.lastIndexOf(".")))){
	                	System.out.println("Similar Files:" + " " + target_file);
	                     docName=targetFolder+target_file;
	                }
	           }
	     }    
	
	}
}
