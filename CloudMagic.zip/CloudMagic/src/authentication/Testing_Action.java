package authentication;

import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.InputStream;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.Map;

import javax.servlet.ServletContext;
import javax.servlet.ServletOutputStream;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.struts2.ServletActionContext;
import org.apache.struts2.interceptor.SessionAware;

import Testing.Database_Access;

import com.itextpdf.text.BaseColor;
import com.itextpdf.text.Chunk;
import com.itextpdf.text.Document;
import com.itextpdf.text.DocumentException;
import com.itextpdf.text.Element;
import com.itextpdf.text.Font;
import com.itextpdf.text.FontFactory;
import com.itextpdf.text.Paragraph;
import com.itextpdf.text.Phrase;
import com.itextpdf.text.pdf.PdfPCell;
import com.itextpdf.text.pdf.PdfPTable;
import com.itextpdf.text.pdf.PdfWriter;
import com.itextpdf.text.pdf.draw.DottedLineSeparator;
import com.opensymphony.xwork2.ActionSupport;

public class Testing_Action extends ActionSupport{
	/**
	 * 
	 */
	 public String execute() {
	    	//Request and Response
	    	HttpServletResponse response=ServletActionContext.getResponse();
	        HttpServletRequest request = ServletActionContext.getRequest();
	        ArrayList dataList=Database_Access.getDataList("-1","-1","-1");
	        ArrayList temp=new ArrayList();
	        
	        if(dataList.size()>0){
	        	for(int i=0;i<dataList.size();i++){
	        		temp=(ArrayList)dataList.get(i);
	        		for(int j=0;j<temp.size();j++){
	        			Testing_Action test=new Testing_Action();
	        			int checkStatus=test.getCheckStatus(dataList);
	        		}
	        		
	        	}
	        }else{
	        	System.out.println("No data Found");
	        }
	        return SUCCESS;

	    }
	 public int getCheckStatus(ArrayList dataList){
		 int count=0;
		 for(int i=0;i<dataList.size();i++){
			 
		 }
		 return count;
	 }
	}
