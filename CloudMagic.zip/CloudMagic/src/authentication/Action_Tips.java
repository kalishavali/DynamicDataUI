package authentication;



import com.opensymphony.xwork2.ActionSupport;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.struts2.ServletActionContext;

 

public class Action_Tips{

    public String execute() {
    	//Request and Response
    	HttpServletResponse response=ServletActionContext.getResponse();
        HttpServletRequest request = ServletActionContext.getRequest();
        String name=request.getParameter("name");

        return "SUCCESS";

    }

}
