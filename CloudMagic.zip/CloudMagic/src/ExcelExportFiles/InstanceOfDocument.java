package ExcelExportFiles;


import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.util.Date;

import org.apache.poi.hssf.usermodel.HSSFWorkbook;
import org.apache.poi.hssf.util.CellRangeAddress;
import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.CellStyle;
import org.apache.poi.ss.usermodel.CreationHelper;
import org.apache.poi.ss.usermodel.IndexedColors;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.ss.usermodel.Sheet;
import org.apache.poi.ss.usermodel.Workbook;
import org.apache.poi.ss.util.WorkbookUtil;

public class InstanceOfDocument {
	public static void main(String[] args) throws IOException {
		
		//Instantiating
		Workbook wb=new HSSFWorkbook();
		CreationHelper createHelper=wb.getCreationHelper();
		
		//Creating Sheets
		Sheet sheet1=wb.createSheet("FirstSheet");
		sheet1.addMergedRegion(new CellRangeAddress(
	            1, //first row (0-based)
	            1, //last row  (0-based)
	            1, //first column (0-based)
	            2  //last column  (0-based)
	    ));
		String safeName=WorkbookUtil.createSafeSheetName("[O' Berlin ?*kk]");
		Sheet sheet2=wb.createSheet(safeName);
		
		//Creating Rows 
		/****   Start From Index 0  ****/
		Row row=sheet1.createRow((short)0);
		
		//Creating Cells
		row.createCell(1).setCellValue(2);
		row.createCell(2).setCellValue(createHelper.createRichTextString("This is Kalishavali"));
		row.createCell(3).setCellValue(true);
		
		/****   Date  ****/
		CellStyle style = wb.createCellStyle();
	    style.setFillBackgroundColor(IndexedColors.AQUA.getIndex());
	    style.setFillPattern(CellStyle.SOLID_FOREGROUND);
	    Cell cell = row.createCell((short) 1);
	    cell.setCellValue("X");
	    cell.setCellStyle(style);
	    
	    style.setDataFormat(createHelper.createDataFormat().getFormat("m/d/yy h:mm"));
	    
	    cell = row.createCell(7);
	    cell.setCellValue(new Date());
	    cell.setCellStyle(style);
		
		//Flushing the output
		FileOutputStream out=new FileOutputStream("workbook.xls");
		wb.write(out);
		out.close();
		System.out.println("Excel Created:");
	}
}
