package ExcelExportFiles;

import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;

import org.apache.poi.hssf.usermodel.HSSFWorkbook;
import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.CellStyle;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.ss.usermodel.Sheet;
import org.apache.poi.ss.usermodel.Workbook;

public class Oops_Excel {
	public static void main(String[] args) throws IOException {
		Workbook wb=new HSSFWorkbook();
		Sheet sheet1=wb.createSheet();
		Row row=sheet1.createRow((short)2);
		row.setHeightInPoints(30);
		createCell(wb, row, (short) 0, CellStyle.ALIGN_CENTER, CellStyle.VERTICAL_BOTTOM,"first");
		createCell(wb, row, (short) 1, CellStyle.ALIGN_CENTER_SELECTION, CellStyle.VERTICAL_BOTTOM,"second");
        createCell(wb, row, (short) 2, CellStyle.ALIGN_FILL, CellStyle.VERTICAL_CENTER,"third");
        createCell(wb, row, (short) 3, CellStyle.ALIGN_GENERAL, CellStyle.VERTICAL_CENTER,"fourth");
        createCell(wb, row, (short) 4, CellStyle.ALIGN_JUSTIFY, CellStyle.VERTICAL_JUSTIFY,"fifth");
        createCell(wb, row, (short) 5, CellStyle.ALIGN_LEFT, CellStyle.VERTICAL_TOP,"six");
        createCell(wb, row, (short) 6, CellStyle.ALIGN_RIGHT, CellStyle.VERTICAL_TOP,"seven");
		
		//Output
		FileOutputStream fileout=new FileOutputStream("OOps_Excel.xls");
		wb.write(fileout);
		fileout.close();
	}
	//CreateCell
	private static void createCell(Workbook wb,Row row,short column,short halign,short valign,String value){
		Cell cell=row.createCell(column);
		cell.setCellValue(value);
		CellStyle cellStyle=wb.createCellStyle();
		cellStyle.setAlignment(halign);
		cellStyle.setVerticalAlignment(valign);
		cell.setCellStyle(cellStyle);
	}
}
