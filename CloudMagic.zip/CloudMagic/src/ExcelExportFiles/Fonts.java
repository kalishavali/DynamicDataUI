package ExcelExportFiles;

import java.io.FileOutputStream;
import java.io.IOException;

import org.apache.poi.hssf.usermodel.HSSFWorkbook;
import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.CellStyle;
import org.apache.poi.ss.usermodel.Font;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.ss.usermodel.Sheet;
import org.apache.poi.ss.usermodel.Workbook;

public class Fonts {
	public static void main(String[] args) throws IOException {
		Workbook wb=new HSSFWorkbook();
		Sheet sheet=wb.createSheet();
		Row row=sheet.createRow((short)1);
		
		/**************   Font      *********************/
		
		Font font=wb.createFont();
		font.setFontHeightInPoints((short)12);
		font.setBoldweight(Font.BOLDWEIGHT_BOLD);
		font.setFontName("Microsoft PhagsPa");
		//font.setItalic(true);
		font.setStrikeout(true);
		
		/**************    Font     *********************/
		
		CellStyle style=wb.createCellStyle();
		style.setFont(font);
		Cell cell=row.createCell(1);
		cell.setCellValue("This is Kalishavali");
		cell.setCellStyle(style);
		
		 // Write the output to a file
	    FileOutputStream fileOut = new FileOutputStream("Font.xls");
	    wb.write(fileOut);
	    fileOut.close();
	  
	}
}
