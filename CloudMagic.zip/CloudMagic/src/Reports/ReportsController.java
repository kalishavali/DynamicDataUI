package Reports;

import java.util.ArrayList;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import org.apache.struts2.ServletActionContext;

import DAO.ReportsDao;
import DAOImpl.ReportsDaoImpl;
import Testing.Database_Access;
import com.opensymphony.xwork2.ActionSupport;

public class ReportsController extends ActionSupport{
	/**
	 * 
	 */
	HttpServletResponse response=ServletActionContext.getResponse();
    HttpServletRequest request = ServletActionContext.getRequest();
    private ArrayList<String> commonData=new ArrayList<String>();
    private ArrayList<ArrayList<String>> Headings=new ArrayList<ArrayList<String>>();
    private ArrayList<ArrayList<String>> Data=new ArrayList<ArrayList<String>>();
    ReportsDao rdao=new ReportsDaoImpl();
	 public String execute() {
	    	//Request and Response
	    	HttpServletResponse response=ServletActionContext.getResponse();
	        HttpServletRequest request = ServletActionContext.getRequest();
	        return SUCCESS;
	 }
	 public String FirstReport() throws Exception{
		 
		 String id="";
		 ArrayList idlist=null;
		 String did="-1",mid="-1",pid="-1",sid="01",lStryear="",lStrmonth="",reportLevel="";
		 //For IDS
		 if (request.getParameter("id") != null) {
				id = (String) request.getParameter("id");
				idlist = rdao.getId(id);
				if(idlist.size()>=1){
					did=(String) idlist.get(0);
				}
				if(idlist.size()>=2){
					mid=(String) idlist.get(1);
				}
				if(idlist.size()>=3){
					pid=(String) idlist.get(2);
				}
		 }
		 request.setAttribute("id",id);
		 //Link Values
		 if(did.equals("-1")){ //District Level
			 request.setAttribute("LinkValue","1");
			 reportLevel="State";
		 }
		 else if(!did.equals("-1") && mid.equals("-1")){ //Mandal Level
			 request.setAttribute("LinkValue","1");
			 reportLevel="District";
		 }
		 else if(!mid.equals("-1") && pid.equals("-1")){ //Panchayat Level
			 request.setAttribute("LinkValue","1");
			 reportLevel="Mandal";
		 }else{  //GP Level
			 request.setAttribute("LinkValue","-1");
			 reportLevel="Panchayat";
		 }
		 commonData=rdao.getAllCommonDtls(sid, did, mid, pid,lStryear, lStrmonth);
 		 Headings=rdao.getHeadings(did,mid,pid);
		 Data=rdao.getDataList(did,mid,pid);
		 request.setAttribute("commonData",commonData);
		 request.setAttribute("Headings",Headings);
		 request.setAttribute("Data",Data);
		 request.setAttribute("reportLevel",reportLevel);
		 request.setAttribute("reportName", "R3.Panta Sanjeevini");
		 
		 return SUCCESS;
	 }
	public HttpServletResponse getResponse() {
		return response;
	}
	public void setResponse(HttpServletResponse response) {
		this.response = response;
	}
	public HttpServletRequest getRequest() {
		return request;
	}
	public void setRequest(HttpServletRequest request) {
		this.request = request;
	}
	public ArrayList<String> getCommonData() {
		return commonData;
	}
	public void setCommonData(ArrayList<String> commonData) {
		this.commonData = commonData;
	}
	public ArrayList<ArrayList<String>> getHeadings() {
		return Headings;
	}
	public void setHeadings(ArrayList<ArrayList<String>> headings) {
		Headings = headings;
	}
	public ArrayList<ArrayList<String>> getData() {
		return Data;
	}
	public void setData(ArrayList<ArrayList<String>> data) {
		Data = data;
	}
	}
