package Testing;

import com.itextpdf.text.BaseColor;
import com.itextpdf.text.Chunk;
import com.itextpdf.text.Document;
import com.itextpdf.text.DocumentException;
import com.itextpdf.text.Font;
import com.itextpdf.text.Paragraph;
import com.itextpdf.text.pdf.PdfWriter;
import com.lowagie.text.FontFactory;

import java.io.FileNotFoundException;
import java.io.FileOutputStream;

public class SuperSubScriptExample {
  public static void main(String[] args) {

    Document document = new Document();

    try {
      PdfWriter.getInstance(document,
            new FileOutputStream("SuperSubScript.pdf"));
      document.open();
      Paragraph p1=new Paragraph();
      Chunk chunk1=new Chunk("Normal Text");
      p1.add(chunk1);
      
      Chunk chunk2=new Chunk("SuperScript");
      chunk2.setTextRise(5f);
      p1.add(chunk2);
      
      Chunk chunk3=new Chunk("Subscript");
      chunk3.setTextRise(-5f);
      p1.add(chunk3);
      //Chemical Formula
      Font f=new Font(Font.FontFamily.COURIER,5,Font.ITALIC);
      Paragraph p2=new Paragraph();
      Chunk first=new Chunk("H");
      Chunk second = new Chunk("2"); 
      Chunk third=new Chunk("SO");
      Chunk fourt=new Chunk("4");
      second.setTextRise(-1f);
      fourt.setTextRise(4f);
      p2.add(first);
      p2.add(second);
      p2.add(third);
      p2.add(fourt);
      
      document.add(p1);
      document.add(p2);
      document.close();
    } catch (DocumentException e) {
      e.printStackTrace();
    } catch (FileNotFoundException e) {
      e.printStackTrace();
    }

  }

}
