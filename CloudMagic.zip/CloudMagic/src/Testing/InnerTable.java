package Testing;
import java.io.*;
import com.itextpdf.*;
import com.itextpdf.text.*;
import com.itextpdf.text.pdf.*;
public class InnerTable {
	public static void main(String[] args){
		Document document=new Document();
		try{
		PdfWriter.getInstance(document,new FileOutputStream("Inner_Table.pdf"));
		// table 2
		final PdfPTable table2 = new PdfPTable(1);
		table2.setHorizontalAlignment(Element.ALIGN_LEFT);
		table2.getDefaultCell().setBorderColor(BaseColor.RED);
		table2.getDefaultCell().setBorderWidth(1);
		table2.addCell("Goodbye World");
		// table 1
		final PdfPTable table1 = new PdfPTable(1);
		table1.setHorizontalAlignment(Element.ALIGN_LEFT);
		table1.setWidthPercentage(100);
		// contents
		PdfPCell cell = new PdfPCell();
		cell.setBorderColor(BaseColor.BLACK);
		cell.setBorderWidth(1);
		cell.addElement(new Chunk("Hello World"));
		cell.addElement(table2);
		cell.addElement(new Chunk("Hello World"));
		table1.addCell(cell);
		document.add(table1);

		}
		catch(DocumentException e){
			e.printStackTrace();
		}
		catch(FileNotFoundException e){
			e.printStackTrace();
		}
	}
}
