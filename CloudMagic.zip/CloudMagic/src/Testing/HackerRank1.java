package Testing;

import java.io.BufferedReader;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.lang.annotation.Retention;
import java.lang.annotation.Target;
import java.lang.reflect.Method;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.HashSet;
import java.util.Scanner;
import java.util.Set;
import static java.lang.System.in;

class Add{
	static void display(int... values){
		int sum=0;
		for(int s:values){
			System.out.print(s);
			System.out.print(s==values.length?"=":"+");
			sum=sum+s;
		}
		System.out.print(sum);
		System.out.println();
	}
	void tring(){
		
	}
	void tring(int a){
		
	}
}
class Prime{
	void checkPrime(int...values){
		for(int s:values){
			boolean flag=true;
			for(int i=2;i<s;i++){
				if(s%i==0){
					flag=false;
					break;
				}
			}
			if(s!=1 && flag)
				System.out.print(s +" ");
		}
		System.out.println();
	}
}
interface Food {
	 public String getType();
}
class Pizza implements Food {
	 public String getType() {
		 return "Someone ordered a Fast Food!";
	 }
}
class Cake implements Food {
	public String getType() {
		return "Someone ordered a Dessert!";
	}
}
class FoodFactory {
	public Food getFood(String order) {
		if(order.equalsIgnoreCase("Pizza")){
			return new Pizza();
		}else{
			return new Cake();
		}
		
	}
}
class myCalculator{
	public int power(int a,int b) throws Exception{
		if(a<0 || b<0)
			throw new Exception("n and p should be non-negative");
		return (int)Math.pow(a,b);
	}
}
public class HackerRank1 {
	
	/*public static void main(String[] args){
		try{
		Add dis=new Add();
		dis.display(1);
		dis.display(1,2);
		Method[] methods=Add.class.getDeclaredMethods();
		Set<String> set=new HashSet<String>();
		boolean overload=false;
		for(Method s:methods){
			System.out.println("Method:"+s.getName());
			if(set.contains(s.getName())){
				overload=true;
				break;
			}
			set.add(s.getName());
		}
		if(overload){
			throw new Exception("Overload Not Allowed");
		}
		}
		catch(Exception e){
			e.printStackTrace();
		}
	
		}*/
	/*public static void main(String[] args) {
	       int test_cases;
	       Scanner in=new Scanner(System.in);
	       test_cases=in.nextInt();
	       double x;
	       for(int i=0;i<test_cases;i++){
	          x=in.nextDouble();
	          double ans=Math.sqrt(x);
	          System.out.println(ans);
	          if(ans*ans==x){
	             System.out.println("YES");
	          }
	          else {
	        	  System.out.println("NO");
	          }

	       }
	    }*/
		/*static class Inner
		{
			private class Private{
				private String powerof2(int num)
				{
					return ((num&num-1)==0)?"power of 2":"not a power of 2";
				}
			}
		}
		public static void main(String[] args) {
			Object o;
			Inner inner=new Inner();
			o=inner.new Private();
			String res=((Testing.HackerRank1.Inner.Private) o).powerof2(7);
			System.out.println(res);
			System.out.println("An instance of class: "+o.getClass().getCanonicalName()+" has been created");
			o=(new HackerRank1.Inner()).new Private();
			System.out.println(num +" is "+ ((HackerRank1.Inner.Private) o).powerof2(num));
			 
		}*/
		
		/*public static void main(String[] args) {
			try{
			BufferedReader br=new BufferedReader(new InputStreamReader(in));
			int n1=Integer.parseInt(br.readLine());
			int n2=Integer.parseInt(br.readLine());
			int n3=Integer.parseInt(br.readLine());
			int n4=Integer.parseInt(br.readLine());
			int n5=Integer.parseInt(br.readLine());
			Prime ob=new Prime();
			ob.checkPrime(n1);
			ob.checkPrime(n1,n2);
			ob.checkPrime(n1,n2,n3);
			ob.checkPrime(n1,n2,n3,n4,n5);	
		}catch(Exception e){
			System.out.println(e);
		}
		}*/
	
		/*public static void main(String[] args) {
			Scanner sc=new Scanner(System.in);
			FoodFactory foodFactory=new FoodFactory();
			Food food=foodFactory.getFood(sc.nextLine());
			System.out.println("The factory returned "+food.getClass());
			System.out.println(food.getType());
		}*/
	
		public static void main(String[] args) {
			SimpleDateFormat simpleDateFormat =
		        new SimpleDateFormat("dd/MM/yyyy");
			System.out.println(new Date());
		String date = simpleDateFormat.format(new Date());
		System.out.println(date);
		}

}
