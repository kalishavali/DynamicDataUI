package Testing;

import com.itextpdf.text.*;
import com.itextpdf.text.pdf.PdfPCell;
import com.itextpdf.text.pdf.PdfPTable;
import com.itextpdf.text.pdf.PdfWriter;

import java.io.FileOutputStream;
import java.io.FileNotFoundException;

/**

 */
public class TableExample {

    public static void main(String[] args) {
    	Document document=new Document();
    	try{
    		PdfWriter.getInstance(document, new FileOutputStream("Table_Example.pdf"));
    		//without opening document we can add only meta information
    		
    		document.open();
    		
    		//Table 1
    		PdfPTable table=new PdfPTable(3);
    		
    		table.setWidthPercentage(100);
    		table.setSpacingBefore(10f);
    		table.setSpacingAfter(10f);
    		float[] columnWidths={2f,1f,1f};
    		table.setWidths(columnWidths);
    		PdfPCell cell1=new PdfPCell(new Paragraph("First"));
    		/*cell1.setBackgroundColor(BaseColor.BLUE);*/
    		PdfPCell cell2=new PdfPCell(new Paragraph("Second"));
    		PdfPCell cell3=new PdfPCell(new Paragraph("third"));
    		table.addCell(cell1);
    		table.addCell(cell2);
    		table.addCell(cell3);
    		PdfPCell cell4=new PdfPCell(new Paragraph("First"));
    		PdfPCell cell5=new PdfPCell(new Paragraph("Second"));
    		PdfPCell cell6=new PdfPCell(new Paragraph("third"));
    		table.addCell(cell4);
    		table.addCell(cell5);
    		table.addCell(cell6);
    		document.add(table);
    		
    		//Table2
    		PdfPTable table1=new PdfPTable(5);
    		PdfPCell cell;
    		cell=new PdfPCell(new Phrase("S.No"));
    		cell.setRowspan(2);
    		/*cell.setBackgroundColor(BaseColor.ORANGE);
    		cell.setUseVariableBorders(true);
    		cell.setBorderColorTop(BaseColor.RED);
    		cell.setBorderColorBottom(BaseColor.BLUE);*/
    		table1.addCell(cell);
    		cell=new PdfPCell(new Phrase("Name"));
    		cell.setColspan(3);
    		table1.addCell(cell);
    		cell=new PdfPCell(new Phrase("Age"));
    		cell.setRowspan(2);
    		table1.addCell(cell);
    		cell=new PdfPCell(new Phrase("SurName"));
    		table1.addCell(cell);
    		cell=new PdfPCell(new Phrase("FirstName"));
    		table1.addCell(cell);
    		cell=new PdfPCell(new Phrase("MiddleName"));
    		table1.addCell(cell);
    		document.add(table1);
    		
    		
    		
    		
    		
    		
    		document.close();
    	}
    	catch(DocumentException e){
    		e.printStackTrace();
    	}
    	catch(FileNotFoundException e){
    		e.printStackTrace();
    	}
    }
}