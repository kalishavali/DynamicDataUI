package Testing;

import com.itextpdf.text.*;
import com.itextpdf.text.pdf.PdfPCell;
import com.itextpdf.text.pdf.PdfPTable;
import com.itextpdf.text.pdf.PdfWriter;

import java.io.File;
import java.io.FileOutputStream;
import java.io.FileNotFoundException;
import java.util.ArrayList;

/**

 */
public class testing {

    public static void main(String[] args) {
    	String fname="Kalishavali.pdf";
    	String path="C:\\Files\\";
    	File oldfile =new File(path+fname);
		File newfile =new File(path);
		
		if(oldfile.renameTo(newfile)){
			System.out.println("Rename succesful");
		}else{
			System.out.println("Rename failed");
		}
    }
}