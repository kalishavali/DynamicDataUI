package Testing;

import com.itextpdf.text.*;
import com.itextpdf.text.pdf.PdfWriter;

import java.io.FileNotFoundException;
import java.io.FileOutputStream;

public class ChapterSection {

  public static void main(String[] args) {

    Document document = new Document();

    try {
      PdfWriter.getInstance(document,
            new FileOutputStream("ChapterSection.pdf"));

      document.open();

      Paragraph paragraph = new Paragraph("BE THE CODER");
      document.add(paragraph);

      Chapter chapter1 = new Chapter("Chapte 1", 1); //Creates a new page
      Section section11 = chapter1.addSection("Section 11");
      section11.add(new Paragraph("Some text in Section 11"));
      Section section12 = chapter1.addSection("Section 12");
      Section section13 = chapter1.addSection("Section 13");
      
      Section section111 = section11.addSection("Section 111");
      Section section121 = section12.addSection("Section 121");
      Section section131 = section13.addSection("Section 131");
      
      section131.addSection("Section 1311");
      section131.addSection("Section 1312").add(new Paragraph("Some text in Section 1312"));
      
      document.add(chapter1);
      document.close();

    } catch (DocumentException e) {
      e.printStackTrace();
    } catch (FileNotFoundException e) {
      e.printStackTrace();
    }

  }
}
