package Testing;

import com.itextpdf.text.Document;
import com.itextpdf.text.DocumentException;
import com.itextpdf.text.Font;
import com.itextpdf.text.FontFactory;
import com.itextpdf.text.Paragraph;
import com.itextpdf.text.pdf.BaseFont;
import com.itextpdf.text.pdf.PdfWriter;
 
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;

public class UnicodeExmaple {
	public static void main(String[] args) {

	    Document document = new Document();
	    String dest="results/Unicode.pdf";

	    try {
	    	
	        PdfWriter.getInstance(document, new FileOutputStream(dest));
	        document.open();
	    	Font font = FontFactory.getFont("Fonts/FreeSans.ttf", BaseFont.IDENTITY_H, BaseFont.EMBEDDED);
	        document.add(new Paragraph("\u00ea \u00f9 ", font));
	        document.close();

	    } catch (DocumentException e) {
	      e.printStackTrace();
	    } catch (FileNotFoundException e) {
	      e.printStackTrace();
	    }

	  }
}
