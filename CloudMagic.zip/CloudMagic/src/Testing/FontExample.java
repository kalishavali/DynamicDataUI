package Testing;

import com.itextpdf.text.*;
import com.itextpdf.text.pdf.PdfWriter;

import java.io.FileOutputStream;
import java.io.FileNotFoundException;

public class FontExample {

  public static void main(String[] args) {

    Document document = new Document();

    try {
      PdfWriter.getInstance(document,
        new FileOutputStream("Font.pdf"));
      
      Font font1=new Font(Font.FontFamily.HELVETICA,25,Font.BOLD);
      Font font2=new Font(Font.FontFamily.COURIER,18,Font.ITALIC | Font.UNDERLINE);
      Font font3 = new Font(Font.FontFamily.TIMES_ROMAN, 27);
      
      Font font4=FontFactory.getFont("Fonts/Lato-Regular.ttf",Font.DEFAULTSIZE);
      Font font5=FontFactory.getFont("Fonts/Quattrocento-Regular.ttf",Font.DEFAULTSIZE);
      
      document.open();
      document.add(new Chunk(    "This is sentence 1. ", font1));
      document.add(new Phrase(   "This is sentence 2. ", font2));
      document.add(new Paragraph("This is sentence 3. ", font3));
      document.add(new Paragraph("this is Font Lato.",font4));
      document.add(new Paragraph("this is Font Quattrocento.",font5));

      document.close();

    } catch (DocumentException e) {
      e.printStackTrace();
    } catch (FileNotFoundException e) {
      e.printStackTrace();
    }

  }
}
