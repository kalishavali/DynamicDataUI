package Testing;

import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.net.MalformedURLException;
import java.util.ArrayList;
import java.util.regex.Pattern;

import javax.servlet.ServletContext;

import com.itextpdf.text.Chunk;
import com.itextpdf.text.Document;
import com.itextpdf.text.DocumentException;
import com.itextpdf.text.Element;
import com.itextpdf.text.Font;
import com.itextpdf.text.FontFactory;
import com.itextpdf.text.Image;
import com.itextpdf.text.PageSize;
import com.itextpdf.text.Paragraph;
import com.itextpdf.text.Phrase;
import com.itextpdf.text.pdf.PdfPCell;
import com.itextpdf.text.pdf.PdfPTable;
import com.itextpdf.text.pdf.PdfWriter;

public class Testing_PDF {
	public void insertCell(String Data,){
		
	}
	public static void main(String[] args) throws MalformedURLException, IOException{
    	Document document=new Document(PageSize.A4, 0, 0, 0, 0);
    	try{
    		ArrayList<String> commonDataList=new ArrayList<String>();
    		commonDataList.add("2013-2014");
    		commonDataList.add("03");
    		commonDataList.add("March");
    		commonDataList.add("District");
    		commonDataList.add("Guntur");
    		commonDataList.add("Mandal");
    		commonDataList.add("Nadendla");
    		commonDataList.add("Panchayat");
    		commonDataList.add("Ganapavaram");
    		ArrayList<String> DataList=new ArrayList<String>();
    		DataList.add("2013-2014");
    		DataList.add("03");
    		DataList.add("March");
    		DataList.add("District");
    		DataList.add("Guntur");
    		DataList.add("Mandal");
    		DataList.add("NREGS-LOGO.png");
    		DataList.add("Panchayat");
    		DataList.add("Ganapavaram");
    		PdfWriter.getInstance(document, new FileOutputStream("Testing_PDF.pdf"));
    		//without opening document we can add only meta information
    		
    		Font fontData=FontFactory.getFont("D://MyWebsites//CloudMagic//WebContent//Fonts//Quattrocento-Regular.ttf",7);
    		Font fontHead=FontFactory.getFont("D://MyWebsites//CloudMagic//WebContent//Fonts//Quattrocento-Regular.ttf",7,Font.BOLD);
    		document.open();
    		
    		
    		//Table 1
    		PdfPTable table1=new PdfPTable(4);
    		float[] columnWidths = {1f, 3f, 3f,1f};
    		table1.setWidths(columnWidths);
    		PdfPCell ce;
    		
    		Image img = Image.getInstance("D://MyWebsites//CloudMagic//WebContent//images//NREGS-LOGO.png");
    		img.scaleAbsolute(50f,50f);
			ce=new PdfPCell(img);
    		ce.setHorizontalAlignment(ce.LEFT);
			ce.setRowspan(3);
			ce.setBorder(ce.NO_BORDER);
			table1.addCell(ce);
			
			ce=new PdfPCell(new Phrase("The Mahatma Gandhi National Rural Employment Guarantee Scheme - AP",fontHead));
			ce.setHorizontalAlignment(ce.ALIGN_CENTER);
			ce.setColspan(2);
			ce.setBorder(ce.NO_BORDER);
			table1.addCell(ce);
			
			Image img1 = Image.getInstance("D://MyWebsites//CloudMagic//WebContent//images//MGNREGS-LOGO.png");
			img1.scaleAbsolute(50f,50f);
			ce=new PdfPCell(img1);
			ce.setHorizontalAlignment(ce.ALIGN_RIGHT);
			ce.setRowspan(3);
			ce.setBorder(ce.NO_BORDER);
			table1.addCell(ce);
			
			ce=new PdfPCell(new Phrase("Under Mahatma Gandhi National Rural Employemnt Guarantee Act-2005",fontHead));
			ce.setHorizontalAlignment(ce.ALIGN_CENTER);
			ce.setColspan(2);
			ce.setBorder(ce.NO_BORDER);
			table1.addCell(ce);
			ce=new PdfPCell(new Phrase("Department of Rural Development, Government of Andhra Pradesh",fontHead));
			ce.setHorizontalAlignment(ce.ALIGN_CENTER);
			ce.setColspan(2);
			ce.setBorder(ce.NO_BORDER);
			table1.addCell(ce);
			
			
			ce=new PdfPCell(new Phrase("ReportName",fontData));
			ce.setHorizontalAlignment(ce.ALIGN_CENTER);
			ce.setColspan(4);
			ce.setBorder(ce.NO_BORDER);
			table1.addCell(ce);
			ce=new PdfPCell(new Phrase("ReportAS ON Date",fontData));
			ce.setHorizontalAlignment(ce.ALIGN_CENTER);
			ce.setColspan(4);
			ce.setBorder(ce.NO_BORDER);
			table1.addCell(ce);
			
			
      		
			Paragraph p3=new Paragraph();
      		if(commonDataList.size()==5)
      			p3.setAlignment(Element.ALIGN_CENTER);
      		else
      			p3.setAlignment(Element.ALIGN_LEFT);
      		
  	    	for(int i = 3; i < commonDataList.size(); i++){
  	    		String ele=commonDataList.get(i);
  	    		p3.add(new Chunk(commonDataList.get(i)+" : " ,fontData));
  	    		p3.add(new Chunk(commonDataList.get(i+1),fontData));
  	    		p3.add(Chunk.TABBING);
  		        i=i+1;
  	    	}
			ce=new PdfPCell(p3);
			ce.setHorizontalAlignment(ce.ALIGN_CENTER);
			//ce.setBorder(ce.NO_BORDER);
			ce.setColspan(4);
			table1.addCell(ce);
			
    		document.add(table1);
    		
    		PdfPTable table=new PdfPTable(DataList.size());

    		table.setWidthPercentage(95);
            table.setSpacingBefore(9f);
            table.setSpacingAfter(0f);
            
            
    		PdfPCell cell;
    		for(int i=0;i<DataList.size();i++){
    			Pattern pattern=Pattern.compile("jpg|png");
    			if(pattern.matcher(DataList.get(i)).find() ){
    				Image img2 = Image.getInstance("D://MyWebsites//CloudMagic//WebContent//images//"+DataList.get(i));
    				ce=new PdfPCell(img2,true);
    				table.addCell(ce);
    			}
    			else{
	    			ce=new PdfPCell(new Phrase(DataList.get(i),fontData));
	    			table.addCell(ce);
    			}
    		}
    		
    		document.add(table);
    		
    		
    		
    		
    		
    		
    		document.close();
    	}
    	catch(DocumentException e){
    		e.printStackTrace();
    	}
    	catch(FileNotFoundException e){
    		e.printStackTrace();
    	}
    }
}
