package Testing;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Date;

import com.itextpdf.text.Document;
import com.itextpdf.text.DocumentException;
import com.itextpdf.text.Element;
import com.itextpdf.text.Font;
import com.itextpdf.text.Paragraph;
import com.itextpdf.text.Phrase;
import com.itextpdf.text.pdf.PdfPCell;
import com.itextpdf.text.pdf.PdfPTable;
import com.itextpdf.text.pdf.PdfWriter;
import java.sql.Timestamp;
import java.util.StringTokenizer;
public class newtest {

    private static Font TIME_ROMAN = 
            new Font(Font.FontFamily.TIMES_ROMAN, 18,Font.BOLD);
    private static Font TIME_ROMAN_SMALL = 
            new Font(Font.FontFamily.TIMES_ROMAN, 12,Font.BOLD);

    /**
     * @param args
     */
    public static void main(String[] args) {

       
    	SimpleDateFormat sdf = new SimpleDateFormat("dd-MMM-yyyy");
    	String date = sdf.format(new Date()); 
    	System.out.println(date);

    }

    

    

    

}
