package Testing;
import com.itextpdf.text.Chunk;
import com.itextpdf.text.Document;
import com.itextpdf.text.DocumentException;
import com.itextpdf.text.Paragraph;
import com.itextpdf.text.pdf.PdfWriter;

import java.io.FileNotFoundException;
import java.io.FileOutputStream;

public class UnderlineStrikethroughExample {
	public static void main(String[] args) {

	    Document document = new Document();

	    try {
	      PdfWriter.getInstance(document,
	            new FileOutputStream("UnderlineStrikethrough.pdf"));

	      document.open();

	      Chunk underline=new Chunk("Underline.  ");
	      underline.setUnderline(1.2f,-2f);
	      document.add(underline);
	      
	      Chunk strikeThrough=new Chunk("StrikeThrough....");
	      strikeThrough.setUnderline(1.2f,2f);
	      document.add(strikeThrough);
	      document.close();

	    } catch (DocumentException e) {
	      e.printStackTrace();
	    } catch (FileNotFoundException e) {
	      e.printStackTrace();
	    }

	  }
}
