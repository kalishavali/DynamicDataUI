package Testing;

import com.itextpdf.text.Document;
import com.itextpdf.text.DocumentException;
import com.itextpdf.text.Paragraph;
import com.itextpdf.text.pdf.PdfWriter;

import java.io.FileOutputStream;
import java.io.FileNotFoundException;

public class Introduction {

    public static void main(String[] args) {
    	//Creating Instance of Document
        Document document = new Document();

        try {
        	//Creating PdfWriter by passing instance and Outputstream to its Constructor
            PdfWriter.getInstance(document,new FileOutputStream("Introduction.pdf"));

            document.open();
            document.add(new Paragraph("A Hello World PDF document."));
            document.close(); // no need to close PDFwriter?

        } catch (DocumentException e) {
            e.printStackTrace();
        } catch (FileNotFoundException e) {
            e.printStackTrace();
        }

    }
}
