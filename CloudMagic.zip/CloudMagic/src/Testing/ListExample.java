package Testing;

import com.itextpdf.text.*;
import com.itextpdf.text.pdf.PdfWriter;

import java.io.FileOutputStream;
import java.io.FileNotFoundException;

/**

 */
public class ListExample {

    public static void main(String[] args) {
    	Document document=new Document();
    	try{
    		PdfWriter.getInstance(document, new FileOutputStream("List_Example.pdf"));
    		//without opening document we can add only meta information
    		document.open();
    		List orderedList=new List(List.ORDERED);
    		orderedList.add("item1");
    		orderedList.add("item2");
    		orderedList.add("item3");
    		document.add(orderedList);
    		List unorderedList=new List(List.UNORDERED);
    		unorderedList.add("item1");
    		unorderedList.add("item2");
    		document.add(unorderedList);
    		RomanList romanList=new RomanList();
    		romanList.add("item1");
    		romanList.add("item2");
    		document.add(romanList);
    		GreekList greekList=new GreekList();
    		greekList.add("greek1");
    		greekList.add("greek2");
    		document.add(greekList);
    		//ZAPFdingbatslist
    		ZapfDingbatsList zapfDingbatsList=new ZapfDingbatsList(40,15);
    		zapfDingbatsList.add(new ListItem("zap1"));
    		document.add(zapfDingbatsList);
    		document.close();
    	}
    	catch(DocumentException e){
    		e.printStackTrace();
    	}
    	catch(FileNotFoundException e){
    		e.printStackTrace();
    	}
    }
}