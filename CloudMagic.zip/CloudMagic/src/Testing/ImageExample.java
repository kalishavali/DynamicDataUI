package Testing;

import com.itextpdf.text.Document;
import com.itextpdf.text.DocumentException;
import com.itextpdf.text.Image;
import com.itextpdf.text.PageSize;
import com.itextpdf.text.Paragraph;
import com.itextpdf.text.pdf.PdfContentByte;
import com.itextpdf.text.pdf.PdfGState;
import com.itextpdf.text.pdf.PdfWriter;

import java.io.FileOutputStream;
import java.net.URL;

public class ImageExample {
  public static void main(String[] args) {
    Document document = new Document();

    try {
    	
    	/*
    	 ***** Scaling Methods  ******
    	scaleAbsolute()
    	scaleAbsoluteWidth()
    	scaleAbsoluteHeight()
    	scalePercentage()
    	scaleToFit()
    	
    	***** Rotation Methods  ******
    	setRotationDegrees()
		setRotation()
		
    	*/
        PdfWriter.getInstance(document,
                new FileOutputStream("Image.pdf"));
        document.open();
        String url="watermark.jpg";
        Image image1 = Image.getInstance(url);
        image1.setAbsolutePosition(50f, 60f);
       	image1.scaleAbsolute(15f,15f);
        image1.scalePercent(30f);
        document.add(image1);
        
        //From Url
        /*String imageUrl = "http://acsfoundation.com.au/bdi/assets/img/logos/tcs.jpg";
        Image image2 = Image.getInstance(new URL(imageUrl));
        document.add(image2);*/

        
        //Rotation
       /* Image image2=Image.getInstance(url);
        image2.setRotationDegrees(45f);
        document.add(image2);*/
        
        
        
        document.close();
    } catch(Exception e){
      e.printStackTrace();
    }
  }

}
